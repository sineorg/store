import assert from "node:assert/strict";
import test from "node:test";

import { installSinePinnedFolderColors } from "../pinned-folder-colors.uc.mjs";

const INSTANCE_KEY = "__sinePinnedFolderColors";

function createNode(state) {
  const attributes = new Map();
  const properties = new Map();
  const node = {
    attributes,
    children: [],
    classList: { add() {} },
    hidden: false,
    removed: false,
    style: {
      getPropertyValue(name) {
        return properties.get(name) ?? "";
      },
      removeProperty(name) {
        properties.delete(name);
      },
      setProperty(name, value) {
        properties.set(name, value);
      },
    },
    addEventListener(_name, _listener, options = {}) {
      if (options.signal) {
        state.signals.push(options.signal);
      }
    },
    append(...children) {
      node.children.push(...children);
    },
    before(...siblings) {
      state.inserted.push(...siblings);
    },
    getAttribute(name) {
      return attributes.get(name) ?? null;
    },
    remove() {
      node.removed = true;
    },
    removeAttribute(name) {
      attributes.delete(name);
    },
    setAttribute(name, value) {
      attributes.set(name, String(value));
    },
    toggleAttribute(name, enabled) {
      if (enabled) {
        attributes.set(name, "");
      } else {
        attributes.delete(name);
      }
    },
  };
  state.nodes.push(node);
  return node;
}

function createHarness(promiseInitialized = Promise.resolve()) {
  const state = {
    cancelledFrames: [],
    inserted: [],
    nodes: [],
    observers: [],
    requestedFrames: [],
    signals: [],
  };
  const documentElement = createNode(state);
  const folderActions = createNode(state);
  const insertionPoint = createNode(state);
  const document = {
    documentElement,
    createXULElement() {
      return createNode(state);
    },
    getElementById(id) {
      if (id === "zenFolderActions") {
        return folderActions;
      }
      if (id === "context_zenFolderChangeIcon") {
        return insertionPoint;
      }
      return null;
    },
    querySelectorAll() {
      return [];
    },
  };
  const preferences = {
    added: [],
    removed: [],
    addObserver(name, observer) {
      preferences.added.push([name, observer]);
    },
    getBoolPref(_name, fallback) {
      return fallback;
    },
    getIntPref(_name, fallback) {
      return fallback;
    },
    getStringPref(_name, fallback) {
      return fallback;
    },
    removeObserver(name, observer) {
      preferences.removed.push([name, observer]);
    },
  };
  class FakeMutationObserver {
    constructor(callback) {
      this.callback = callback;
      this.disconnected = false;
      state.observers.push(this);
    }

    disconnect() {
      this.disconnected = true;
    }

    observe() {}
  }
  const windowRef = {
    document,
    gBrowser: { tabContainer: {} },
    gZenWorkspaces: { promiseInitialized },
    addEventListener(_name, _listener, options = {}) {
      if (options.signal) {
        state.signals.push(options.signal);
      }
    },
    cancelAnimationFrame(frameId) {
      state.cancelledFrames.push(frameId);
    },
    requestAnimationFrame() {
      const frameId = state.requestedFrames.length + 1;
      state.requestedFrames.push(frameId);
      return frameId;
    },
  };

  return {
    FakeMutationObserver,
    folderActions,
    preferences,
    state,
    windowRef,
  };
}

async function settleInitialization() {
  await Promise.resolve();
  await Promise.resolve();
}

test("unload removes runtime observers, listeners, UI, styles, and singleton", async () => {
  const harness = createHarness();
  const teardown = installSinePinnedFolderColors(
    harness.windowRef,
    harness.preferences,
    harness.FakeMutationObserver
  );
  await settleInitialization();

  assert.equal(harness.preferences.added.length, 4);
  assert.equal(harness.state.observers.length, 1);
  assert.equal(harness.windowRef[INSTANCE_KEY]?.destroy, teardown);

  harness.state.observers[0].callback();
  assert.deepEqual(harness.state.requestedFrames, [1]);

  teardown();

  assert.equal(harness.windowRef[INSTANCE_KEY], undefined);
  assert.equal(harness.preferences.removed.length, 4);
  assert.equal(harness.state.observers[0].disconnected, true);
  assert.deepEqual(harness.state.cancelledFrames, [1]);
  assert.ok(harness.state.signals.every(signal => signal.aborted));
  assert.ok(
    harness.state.nodes
      .filter(node =>
        [
          "sine-pinned-folder-colors-menu",
          "sine-pinned-folder-colors-separator",
        ].includes(node.id)
      )
      .every(node => node.removed)
  );

  teardown();
  assert.equal(harness.preferences.removed.length, 4);
});

test("unload before Zen initializes prevents a late runtime installation", async () => {
  let resolveInitialization;
  const initialized = new Promise(resolve => {
    resolveInitialization = resolve;
  });
  const harness = createHarness(initialized);
  const teardown = installSinePinnedFolderColors(
    harness.windowRef,
    harness.preferences,
    harness.FakeMutationObserver
  );

  teardown();
  resolveInitialization();
  await settleInitialization();

  assert.equal(harness.windowRef[INSTANCE_KEY], undefined);
  assert.equal(harness.preferences.added.length, 0);
  assert.equal(harness.state.observers.length, 0);
  assert.equal(harness.state.signals.length, 0);
});

test("installing again destroys the earlier runtime before replacement", async () => {
  const harness = createHarness();
  const firstTeardown = installSinePinnedFolderColors(
    harness.windowRef,
    harness.preferences,
    harness.FakeMutationObserver
  );
  await settleInitialization();
  const firstObserver = harness.state.observers[0];

  const secondTeardown = installSinePinnedFolderColors(
    harness.windowRef,
    harness.preferences,
    harness.FakeMutationObserver
  );
  await settleInitialization();

  assert.notEqual(firstTeardown, secondTeardown);
  assert.equal(firstObserver.disconnected, true);
  assert.equal(harness.preferences.removed.length, 4);
  assert.equal(harness.state.observers.length, 2);
  assert.equal(harness.windowRef[INSTANCE_KEY]?.destroy, secondTeardown);

  secondTeardown();
  assert.equal(harness.windowRef[INSTANCE_KEY], undefined);
  assert.equal(harness.preferences.removed.length, 8);
});
