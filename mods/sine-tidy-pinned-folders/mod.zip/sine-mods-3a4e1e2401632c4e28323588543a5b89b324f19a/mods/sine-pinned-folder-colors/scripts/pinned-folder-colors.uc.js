(() => {
  const moduleUrl =
    "chrome://sine/content/sine-pinned-folder-colors/scripts/" +
    `pinned-folder-colors.uc.mjs?v=${Date.now()}`;
  let unloadRequested = false;
  let teardown = null;

  const loadPromise = import(moduleUrl)
    .then(module => {
      if (unloadRequested) {
        return null;
      }

      teardown = module.installSinePinnedFolderColors(window);
      return teardown;
    })
    .catch(error => {
      console.error("[Pinned Folder Colors] Failed to load module:", error);
      return null;
    });

  const unload = async () => {
    unloadRequested = true;
    const loadedTeardown = teardown ?? (await loadPromise);
    loadedTeardown?.();
    teardown = null;
  };

  if (typeof window.addUnloadListener === "function") {
    window.addUnloadListener(unload);
  } else {
    window.addEventListener("unload", () => void unload(), { once: true });
  }
})();
