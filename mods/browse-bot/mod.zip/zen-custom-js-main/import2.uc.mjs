// ==UserScript==
// @include   about:preferences*
// @include   about:settings*
// @ignorecache
// ==/UserScript==

import "./settings-shortcuts-search/settings-shortcuts-search.uc.js";
