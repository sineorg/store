# Unloaded Tabs
Makes unloaded tabs colorless and semi-transparent, so you can easily distinguish them from loaded tabs

![img](https://raw.githubusercontent.com/qumeqa/unloaded-tabs/refs/heads/main/cover.png)
