# New icons
New icons for the toolbar, popups, site data panel, and better locale button

<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/2.jpg" width="100%">

### All changed icons
<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/3.jpg" width="100%">

<!-- ### List of changed icons
- Toggle compact mode
- Back
- Forward
- Reload
- Stop
- Home
- Developer
- Screenshot
- Bookmarks
- History
- Urlbar
- Translations
- Translations (loading)
- Site data
- Nav bar overflow
- Sync -->
