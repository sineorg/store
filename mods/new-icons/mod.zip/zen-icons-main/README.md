# New Icons
New icons for the toolbar, popups, site data panel, and better locale button

<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/icons.jpg" width="100%">

<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/main.jpg" width="100%">
