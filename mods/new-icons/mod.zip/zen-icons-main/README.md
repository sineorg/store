# New toolbar icons
New icons for the toolbar and better locale button. I did it in one evening, so it will still be updated. Enjoy using it😏 Let me know if you want me to change any icons

### Before
<img src="photo/1.png" width="100%">

### After
<img src="photo/2.png" width="100%">

### All changed icons
<img src="photo/3.png" width="100%">

### List of changed icons
- Zen toggle compact mode
- Back
- Forward
- Reload
- Stop
- Home
- Developer
- Screenshot
- Bookmarks menu
- History panel menu
- Urlbar
- Translations
- Translations (loading)
- Site data
- Nav bar overflow
