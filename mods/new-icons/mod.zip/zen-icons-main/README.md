# New toolbar icons
New icons for the toolbar and better locale button. Enjoy using it!

### Before
<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/1.png" width="100%">

### After
<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/2.png" width="100%">

### All changed icons
<img src="https://raw.githubusercontent.com/qumeqa/zen-icons/refs/heads/main/photo/3.png" width="100%">

### List of changed icons
- Toggle compact mode
- Back
- Forward
- Reload
- Stop
- Home
- Developer
- Screenshot
- Bookmarks
- History
- Urlbar
- Translations
- Translations (loading)
- Site data
- Nav bar overflow
- Sync
