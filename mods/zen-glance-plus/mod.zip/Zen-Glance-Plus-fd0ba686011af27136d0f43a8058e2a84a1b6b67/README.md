<p align="center">
  <img src="assets/icon.png" alt="Glance Plus" width="150" height="150">
</p>

<h1 align="center">Glance Plus</h1>

<p align="center">
  <strong>Zen's Glance, without the gesture.</strong><br>
  Pages you choose open over the one you are reading instead of replacing it, and each site decides which of its pages are worth a Glance.
</p>

<p align="center">
  <a href="https://github.com/apoapostolov/Zen-Glance-Plus/releases/latest"><img alt="Release" src="https://img.shields.io/github/v/release/apoapostolov/Zen-Glance-Plus?style=for-the-badge&color=5B8CFF"></a>
  <a href="LICENSE"><img alt="License" src="https://img.shields.io/github/license/apoapostolov/Zen-Glance-Plus?style=for-the-badge&color=5B8CFF"></a>
  <a href="https://github.com/zen-browser/desktop"><img alt="Zen 1.24t" src="https://img.shields.io/badge/zen-1.24t-5B8CFF?style=for-the-badge"></a>
  <img alt="Sine mod" src="https://img.shields.io/badge/sine-mod-5B8CFF?style=for-the-badge">
</p>

<p align="center">
  <img src="assets/settings-panel.png" alt="Glance Plus settings: switches for the tab kinds a Glance applies to, and a table of sites each with Link, New tabs and Domain switches plus its link patterns" width="760">
</p>

## What it changes

Zen's Glance shows a page over the tab you are on. Stock Zen only raises it for a gesture: a modifier click on a link, a bookmark or search result with the modifier held, or a link that leaves an essential tab. Glance Plus makes the Glance the ordinary way a page opens, decided by the kind of tab it came from and, per site, by the kind of page it is.

Both ways a page can open count: a tab the browser creates, and a link inside a page that opens a tab of its own. A post clicked inside its own site's essential is the second kind, and it glances too. The browser's own new tab is left alone — Ctrl+T, the sidebar's plus button, a restored session, and the first tab in an empty workspace all produce an ordinary tab, because a tab that no page asked for has no opener to judge.

## Install

1. In Zen settings, open Sine and add a mod from the repository `apoapostolov/Zen-Glance-Plus`.
2. Check that `sine.allow-unsafe-js` is `true` in `about:config`. A repository install is not a store install, so Sine refuses to run its script without that preference, and the mod then shows as enabled while doing nothing.
3. Restart Zen. Chrome scripts load at startup.

## Settings

Six switches decide every site that has no row of its own, under two headings.

| Setting | Default | Effect |
| --- | --- | --- |
| Essentials | On | A new tab opened from an essential becomes a Glance |
| Pinned Tabs | On | The same for a pinned tab |
| Normal Tabs | Off | The same for an ordinary tab |
| New Tab Pages | On | The same for a New Tab page |
| Same Tab Pages | Off | A page-initiated open that would replace the ordinary tab you are on becomes a Glance instead |
| Same Domain Only | Off | A page glances only when it belongs to the domain it was opened from |

`Same Domain Only` compares the domains themselves, not the hosts, so `old.reddit.com` opening from `reddit.com` still counts as the same place and `github.com` opening from a Reddit tab does not. It holds for a site row as well: with the switch on, no row can glance a page outside its own domain. A New Tab page has no domain to stay in, so nothing opened from one is constrained.

A tab is classified once: essentials first, because they are pinned as well, then pinned tabs, then New Tab pages, which are ordinary tabs carrying Zen's own marker, then ordinary tabs.

### Glance bar

**Bookmark in Glance Bar** is experimental. It reaches into Zen's bookmark dialog to arrange it, and for Raindrop into another extension, so it ships switched off, may change, and may be withdrawn.

It decides whether the Glance's button strip carries a save button, and which one. It sits to the left of Copy link.

| Position | Default | Effect |
| --- | --- | --- |
| Disabled | Yes | No button is drawn |
| Bookmarks | | Zen's own bookmark icon, which opens the add bookmark dialog for the page in the Glance |
| Raindrop | | Raindrop's cloud, which opens its add bookmark dialog for that page |

The Bookmarks position asks for the address the Glance is showing, not the page of whichever tab happens to be selected, so a peeking Glance saves the page you are looking at. The browser's dialog reserves a slot for an icon at the left of its title and fills it with the hollow bookmark it uses for a new bookmark; that slot is cleared for the dialog this button opens, so the dialog carries its title and nothing else. Location and Spaces are placed on one line there — the dialog's own one-column grid puts every field on a line of its own — with the folder menu standing in the place of the word Location — it says where the bookmark goes, and keeps the word as its accessible name — hugging its own text, and Spaces taking the remaining width, so no half-empty box sits between them and the Spaces trigger and expander stay inside their share. Raindrop appears only when the Raindrop.io extension is installed and enabled, and it opens Raindrop's own add bookmark dialog — `index.html#/add?link=…`, in a 420 by 600 popup centred on the window, which is what the extension's address-bar cloud and its save-page shortcut do. The cloud is drawn from a copy carried inside the mod, masked inside the button and filled with the button's own colour, so it takes the same ink as the icons beside it; the add-on's own copy decides its colour with a media query and an opacity, which a dark skin swallows. It opens as a small dialog window in the middle of the screen, 420 by 600, through `openDialog` with `centerscreen,dialog=no,chrome=no`, with the window watcher, `window.open` and finally a tab behind it; the log names the way in that worked. A mod's script runs in a sandbox, so handing any window it can see to a native call is refused with `NS_ERROR_ILLEGAL_VALUE` — the shape is asked for in the features string instead, which needs no window argument.

### Sites

Add a domain, and its row has three switches: **Link** for clicks that would replace the page you are on, **New tabs** for links that open a tab, and **Domain** to keep pages opened from that site inside it. A row answers for its domain and every subdomain, so `reddit.com` covers `old.reddit.com`, and it overrides the switches above in both directions: with **New tabs** off, that site never glances a new tab, even from an essential.

**Domain** is the per-site form of `Same Domain Only`, read from the tab that starts the open rather than from the address being opened: with it ticked on `reddit.com`, a link leaving Reddit opens as an ordinary tab, while `old.reddit.com` still glances because a subdomain is the same site. It is off on every row, including the shipped ones.

Changes save as you make them and apply to the next page you open.

The table starts populated: reddit.com, x.com, facebook.com, youtube.com, instagram.com, github.com and feedly.com, each row narrowed to that site's content pages — a post, a status, a video, an issue, a comment thread, an article in Feedly's own reader — so a fresh install glances something before you touch a setting. A site added to that list in a later version is offered once to installs that already have their own list, and recorded as offered; deleting a row keeps it deleted, and no preset returns on its own.

### Link patterns

Click a site name and the row opens its patterns. With none, every link on the site glances. With patterns, only matching links do, which is how a subreddit's posts open in Glance while its listings, front page and settings stay ordinary tabs:

```
/r/*/comments/*      a post from a subreddit listing
*/comments/*         a post opened from a profile or the front page
/i/entry/*           an article opened in Feedly's reader
```

Patterns match the address path and query, never the domain, because the row already supplies the domain. `*` stands for anything, including `/`. A pattern beginning with `/` is anchored at the path root; one beginning with `*` matches anywhere; one typed without either is read as `*pattern`. A pasted address keeps only its path. Matching is case-sensitive.

## Behaviour worth knowing

- Zen holds one Glance at a time. When a second page matches while one is open, the open one is turned into a real tab and the new page is shown as a Glance.
- A link you follow from inside an open Glance behaves like a link: if the page would have opened in a Glance from the tab the Glance sits over, it loads **in the Glance you are in**. No second Glance is started, and the tab underneath is never used or replaced. A link that explicitly asks for a new tab — a middle click, `Ctrl`-click, or the context menu — opens a new tab, as it says it will. Zen's own rule refuses a Glance opened from a Glance for the same reason; this mod refuses it too and then decides by the tab the Glance sits over.
- A page that would have opened in a background tab opens as a Glance instead, which brings it on screen.
- A link that opens a tab from inside a page — `target="_blank"`, a middle click, `window.open` — is judged on the address it will load, not the empty tab that carries it. That is what makes a post clicked inside its own site's essential open as a Glance, which Zen's own rule refuses because the domains match.
- One thing is out of reach: a plain left click that navigates the tab you are already on creates no tab at all, so there is nothing to divert. **Same Tab Pages** and a row's **Link** switch cover the page-initiated opens that do reach the browser window, such as a context menu's "open link in this tab". Nothing typed in the address bar is affected.
- Essential and pinned tab creation, "open all in tabs", session restore and unloaded opens are left alone.
- The Glance's own button strip can carry a **Bookmark** button to the left of Copy link: Zen's bookmark dialog for the page in the Glance, or Raindrop's own panel when that extension is installed. The setting is under **Glance bar**, and it is off until you choose one.
- The Glance's own button strip carries a fourth button, **Copy link**, drawn with Zen's own link icon so it takes the theme's colour like its neighbours. It copies the address of the page on screen with the browser's own copy action, the same one behind Zen's copy-current-address shortcut and its address bar: the readable form of the link, with tracking parameters stripped as Zen strips them, and the usual confirmation toast. It is there in both states, so it also works while the Glance is only peeking.
- Zen's own Glance switch wins. With Glance turned off in `Settings > Look and Feel`, this mod does nothing.
- Nothing is converted while Zen runs a Glance animation.

## How it works

Two seams, because a page can open a tab in two ways that look different from the browser window.

The first is `gBrowser.addTab`, which every tab the browser creates passes through and which carries the address. The mod records a plan there and converts the new tab on the `TabOpen` event that `addTab` dispatches, handing the opened tab to `gZenGlanceManager.openGlance()` as an existing tab so no second tab is created and no second load starts. `addTab` rather than `TabOpen` alone, because `TabOpen` fires before the browser begins loading, when the tab still holds `about:blank` and there is no address to test.

The second is `gZenGlanceManager.shouldOpenTabInGlance`, Zen's own check. A tab opened by a link inside a page reaches `addTab` empty and loads itself afterwards, so the browser window never sees its address; Zen keeps that address and passes it to its own check along with the tab it created. The mod answers there too, with the same switches and site patterns, and leaves Zen's answer alone when Zen's answer is yes. `docs/glance-internals.md` documents the browser code both rest on, with file and line references from Zen Twilight 1.24t.

## When something does not work

The mod writes `<profile>/zen-glance-plus.log` as it runs: one line when it loads, one when it starts with its hook state and site count, one per tab it decides about, and one for how the settings table was placed. It is the fastest way to tell "the script never ran" from "the script ran and declined", and it costs a few kilobytes at most.

## Testing

```
node tests/zen-glance-plus.test.mjs scripts/zen-glance-plus.uc.js
node tests/sites.test.mjs scripts/zen-glance-plus.uc.js
```

Both harnesses run the shipped script in a Node VM. The first drives stubbed browser globals: every tab kind and its switch, the conversion, the single-Glance conflict, the redirect seam, a site row and its patterns overriding a switch, and the restore path. The second supplies a small DOM and covers the site list from storage to the rendered table and back, including the pattern editor and the three ways the table can find its place in the settings page. `ONLY="New Tab" node tests/zen-glance-plus.test.mjs` runs a subset of either suite.

## Licence

MIT. `CREDITS.md` records what the idea owes to other work.
