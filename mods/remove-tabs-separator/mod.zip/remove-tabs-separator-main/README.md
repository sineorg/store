# Remove Tabs Separator
Removes the container separator for pinned tabs

![img](https://raw.githubusercontent.com/qumeqa/remove-tabs-separator/refs/heads/main/cover.png)
