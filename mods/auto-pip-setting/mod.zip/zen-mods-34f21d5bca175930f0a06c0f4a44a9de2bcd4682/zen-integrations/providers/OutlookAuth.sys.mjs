const {
  isExpired,
  markConnected,
  markExpired,
  outlookAccountId,
  setAccountEmail,
  setAccountMessage
} = ChromeUtils.importESModule(
  'chrome://sine/content/zen-integrations/Accounts.sys.mjs' + new URL(import.meta.url).search
);
const { CONFIG, debugLog, getTabUserContextId, httpRequest, profilePath } = ChromeUtils.importESModule(
  'chrome://sine/content/zen-integrations/Util.sys.mjs' + new URL(import.meta.url).search
);
const { codeChallenge, randomToken } = ChromeUtils.importESModule(
  'chrome://sine/content/zen-integrations/Pkce.sys.mjs' + new URL(import.meta.url).search
);
const {
  OUTLOOK_REDIRECT_URI,
  OUTLOOK_SCOPE,
  OUTLOOK_TOKEN_URL,
  authorizeUrl,
  formEncode,
  graphMessageUrl,
  graphMessagesUrl,
  graphUnreadRows,
  outlookClientState
} = ChromeUtils.importESModule(
  'chrome://sine/content/zen-integrations/providers/OutlookGraph.sys.mjs' + new URL(import.meta.url).search
);

const TOKEN_SKEW_MS = 60000;
const AUTH_TIMEOUT_MS = 180000;

let tokenStore = null;
let tokenWrite = Promise.resolve();
const authInFlight = new Set();

export function readOutlookClientId() {
  try {
    return Services.prefs.getStringPref(CONFIG.OUTLOOK_CLIENT_PREF, '').trim();
  } catch (e) {
    return '';
  }
}

export function outlookSignInMessage() {
  const state = outlookClientState(readOutlookClientId());
  if (state === 'foreign') return "Use your own Microsoft app id. This one belongs to Arc.";
  if (state === 'invalid') return 'zen-integrations.outlook.clientId is not a Microsoft app id';
  if (state === 'ok') return 'Click to sign in to Outlook';
  return '';
}

function signInError(message) {
  const error = new Error(message || 'Sign-in required');
  error.signin = true;
  return error;
}

async function loadTokens() {
  if (tokenStore) return tokenStore;
  let parsed = {};
  try {
    parsed = await IOUtils.readJSON(profilePath(CONFIG.OUTLOOK_TOKEN_FILE));
  } catch (e) {}
  const source = parsed && typeof parsed === 'object' ? parsed : {};
  const migrated = {};
  for (const [key, entry] of Object.entries(source)) {
    const next = outlookAccountId(key);
    if (!migrated[next] || (!migrated[next]?.accessToken && entry?.accessToken)) migrated[next] = entry;
  }
  tokenStore = migrated;
  if (Object.keys(source).some((key) => key !== outlookAccountId(key))) {
    await saveTokens(tokenStore);
  }
  return tokenStore;
}

function saveTokens(store) {
  tokenStore = store;
  const path = profilePath(CONFIG.OUTLOOK_TOKEN_FILE);
  tokenWrite = tokenWrite.then(() => IOUtils.writeJSON(path, store, { tmpPath: path + '.tmp' })).catch((e) => {
    debugLog('Outlook token save failed', e && e.message ? e.message : e);
  });
  return tokenWrite;
}

function outlookKeyParts(contextKey) {
  const parts = String(contextKey || '').split(':');
  return {
    family: parts[1] || '',
    container: parts[parts.length - 1] || '0'
  };
}

function tokenStorageKey(store, contextKey) {
  const wantedKey = outlookAccountId(contextKey);
  if (store[wantedKey]?.accessToken) return wantedKey;
  const wanted = outlookKeyParts(wantedKey);
  // One Outlook account per Firefox container. The tab host can move between
  // live and office, so reuse the token for that container regardless of family.
  for (const key of Object.keys(store)) {
    const other = outlookKeyParts(key);
    if (other.container !== wanted.container) continue;
    if (store[key]?.accessToken) return key;
  }
  return '';
}

async function resolveToken(contextKey) {
  const store = await loadTokens();
  const key = tokenStorageKey(store, contextKey);
  if (!key) return null;
  if (key !== contextKey) debugLog('Outlook token reused', key, 'for', contextKey);
  return { key, entry: store[key] };
}

async function tokenFor(contextKey) {
  const found = await resolveToken(contextKey);
  return found?.entry || null;
}

async function putToken(contextKey, payload, previous) {
  const key = outlookAccountId(contextKey);
  const store = await loadTokens();
  const expiresIn = Number(payload.expires_in) || 3600;
  store[key] = {
    accessToken: payload.access_token,
    refreshToken: payload.refresh_token || previous?.refreshToken || '',
    expiresAt: Date.now() + expiresIn * 1000,
    scope: payload.scope || OUTLOOK_SCOPE
  };
  await saveTokens(store);
  return store[key];
}

async function dropToken(contextKey) {
  const store = await loadTokens();
  const key = tokenStorageKey(store, contextKey) || outlookAccountId(contextKey);
  if (!store[key]) return;
  delete store[key];
  await saveTokens(store);
}

export async function clearOutlookTokens() {
  await saveTokens({});
}

export function dropOutlookToken(contextKey) {
  return dropToken(contextKey);
}

function reconnectError() {
  const error = signInError('Reconnect Outlook');
  error.expired = true;
  return error;
}

async function rememberOutlook(win, userContextId, token, accountKey) {
  try {
    const fetched = await httpRequest(win, {
      url: 'https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName',
      userContextId,
      method: 'GET',
      anonymous: true,
      headers: { Authorization: 'Bearer ' + token, Accept: 'application/json' }
    });
    const payload = JSON.parse(fetched.text || '{}');
    const email = payload.mail || payload.userPrincipalName || '';
    if (email) await setAccountEmail(accountKey, email);
  } catch (e) {}
}

async function postToken(win, userContextId, fields) {
  const fetched = await httpRequest(win, {
    url: OUTLOOK_TOKEN_URL,
    userContextId,
    method: 'POST',
    anonymous: true,
    contentType: 'application/x-www-form-urlencoded;charset=UTF-8',
    headers: { Accept: 'application/json' },
    body: formEncode(fields)
  });
  let payload = {};
  try { payload = JSON.parse(fetched.text || '{}'); } catch (e) {}
  return { status: fetched.status, payload };
}

async function refreshToken(win, userContextId, contextKey, entry, clientId) {
  const found = await resolveToken(contextKey);
  const key = found?.key || contextKey;
  const current = entry || found?.entry;
  if (!current?.refreshToken) return null;
  const { status, payload } = await postToken(win, userContextId, {
    client_id: clientId,
    grant_type: 'refresh_token',
    refresh_token: current.refreshToken,
    scope: OUTLOOK_SCOPE
  });
  if (status < 200 || status >= 300 || !payload.access_token) {
    debugLog('Outlook refresh failed', status, payload.error || '');
    await dropToken(key);
    await markExpired(key);
    return null;
  }
  return putToken(key, payload, current);
}

async function accessToken(win, userContextId, contextKey, clientId) {
  let entry = await tokenFor(contextKey);
  if (!entry) return null;
  if (entry.expiresAt && entry.expiresAt - TOKEN_SKEW_MS > Date.now()) return entry.accessToken;
  entry = await refreshToken(win, userContextId, contextKey, entry, clientId);
  return entry?.accessToken || null;
}

function tabIsOpen(tab) {
  return !!(tab && tab.isConnected && tab.linkedBrowser);
}

function waitForAuthCode(win, tab, state) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let browser = null;
    let armTimer = 0;
    const listener = {
      QueryInterface: ChromeUtils.generateQI(['nsIWebProgressListener', 'nsISupportsWeakReference']),
      onLocationChange(_progress, _request, location) {
        let spec = '';
        try { spec = location?.spec || ''; } catch (e) { return; }
        if (!spec.startsWith(OUTLOOK_REDIRECT_URI)) return;
        let parsed;
        try { parsed = new URL(spec); } catch (e) { return; }
        if (parsed.searchParams.get('state') !== state) return;
        const error = parsed.searchParams.get('error');
        const code = parsed.searchParams.get('code');
        if (error) {
          finish(() => reject(new Error(parsed.searchParams.get('error_description') || error)));
          return;
        }
        if (!code) {
          finish(() => reject(new Error('Microsoft sign-in returned no code')));
          return;
        }
        finish(() => resolve(code));
      }
    };
    const timer = win.setTimeout(() => {
      finish(() => reject(new Error('Microsoft sign-in timed out')));
    }, AUTH_TIMEOUT_MS);
    const onClose = () => finish(() => reject(new Error('Microsoft sign-in closed')));
    function finish(done) {
      if (settled) return;
      settled = true;
      win.clearTimeout(timer);
      win.clearTimeout(armTimer);
      try { browser?.removeProgressListener(listener); } catch (e) {}
      try { tab.removeEventListener('TabClose', onClose); } catch (e) {}
      try { win.gBrowser.removeTab(tab); } catch (e) {}
      done();
    }
    function arm(tries) {
      if (settled) return;
      if (!tab.isConnected) {
        finish(() => reject(new Error('Zen closed the sign-in tab')));
        return;
      }
      browser = tab.linkedBrowser || null;
      if (!browser) {
        if (tries > 40) {
          finish(() => reject(new Error('Zen did not attach a browser to the sign-in tab')));
          return;
        }
        armTimer = win.setTimeout(() => arm(tries + 1), 50);
        return;
      }
      tab.addEventListener('TabClose', onClose);
      try {
        browser.addProgressListener(listener, Ci.nsIWebProgress.NOTIFY_LOCATION);
      } catch (e) {
        finish(() => reject(e));
      }
    }
    arm(0);
  });
}

export async function beginOutlookSignIn(app, tab, contextKey) {
  const clientId = readOutlookClientId();
  const stateName = outlookClientState(clientId);
  if (stateName !== 'ok') return;
  const accountKey = outlookAccountId(contextKey);
  if (authInFlight.has(accountKey)) return;
  authInFlight.add(accountKey);
  const win = app.window;
  const userContextId = getTabUserContextId(tab);
  let authTab = null;
  try {
    if (!win?.gBrowser?.addTab) throw new Error('Zen tab browser is missing');
    const verifier = randomToken(win);
    const state = randomToken(win);
    const url = authorizeUrl({
      clientId,
      redirectUri: OUTLOOK_REDIRECT_URI,
      state,
      challenge: await codeChallenge(win, verifier)
    });
    const addTabArgs = {
      triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal(),
      inBackground: false
    };
    if (userContextId) addTabArgs.userContextId = userContextId;
    authTab = win.gBrowser.addTab(url, addTabArgs);
    win.gBrowser.selectedTab = authTab;
    await new Promise((resolve) => win.setTimeout(resolve, 0));
    if (!tabIsOpen(authTab)) throw new Error('Zen closed the sign-in tab before it opened');
    app.panel.hide();
    const code = await waitForAuthCode(win, authTab, state);
    authTab = null;
    const { status, payload } = await postToken(win, userContextId, {
      client_id: clientId,
      grant_type: 'authorization_code',
      code,
      redirect_uri: OUTLOOK_REDIRECT_URI,
      code_verifier: verifier,
      scope: OUTLOOK_SCOPE
    });
    if (status < 200 || status >= 300 || !payload.access_token) {
      throw signInError(payload.error_description || payload.error || 'Microsoft token request failed');
    }
    const saved = await putToken(accountKey, payload, null);
    await markConnected(accountKey, accountKey);
    await rememberOutlook(win, userContextId, saved.accessToken, accountKey);
    debugLog('Outlook signed in', accountKey);
    if (tab) app.scan.requestScan(tab, { force: true });
  } catch (e) {
    console.warn('[Zen Integrations] Outlook sign-in failed:', e && e.message ? e.message : e);
    debugLog('Outlook sign-in failed', e && e.message ? e.message : e);
    await setAccountMessage(accountKey, e?.message || 'Microsoft sign-in failed');
  } finally {
    authInFlight.delete(accountKey);
    if (authTab) {
      try { win.gBrowser.removeTab(authTab); } catch (e) {}
    }
  }
}

export async function fetchOutlookGraph(app, tab, contextKey) {
  const clientId = readOutlookClientId();
  const stateName = outlookClientState(clientId);
  if (stateName === 'foreign') throw signInError(outlookSignInMessage());
  if (stateName === 'invalid') throw signInError(outlookSignInMessage());
  if (stateName !== 'ok') return null;

  const win = app.window;
  const userContextId = getTabUserContextId(tab);
  let bearer = await accessToken(win, userContextId, contextKey, clientId);
  if (!bearer) throw isExpired(contextKey) ? reconnectError() : signInError(outlookSignInMessage());

  const requestPage = (token, view) => httpRequest(win, {
    url: graphMessagesUrl(view, CONFIG.MAX_EMAILS),
    userContextId,
    method: 'GET',
    anonymous: true,
    headers: {
      Authorization: 'Bearer ' + token,
      Accept: 'application/json'
    },
    maxBytes: 2000000
  });

  // Focused is Prioritaire. Other is Autres. One inbox page of the newest mail
  // fills with Other, so each tab is queried on its own.
  const loadPages = async (token) => {
    const pages = [];
    for (const view of ['focused', 'other']) {
      const fetched = await requestPage(token, view);
      if (fetched.status === 400) {
        debugLog('Outlook Graph skipped view', view, fetched.status);
        if (!pages.length) return [await requestPage(token, '')];
        break;
      }
      pages.push(fetched);
    }
    return pages;
  };

  const readPage = (fetched) => {
    if (fetched.status === 401) throw reconnectError();
    if (fetched.status === 403) throw signInError(outlookSignInMessage());
    if (fetched.status < 200 || fetched.status >= 300) {
      let detail = '';
      try { detail = JSON.parse(fetched.text || '{}').error?.message || ''; } catch (e) {}
      throw new Error(detail ? 'Graph HTTP ' + fetched.status + ': ' + detail : 'Graph HTTP ' + fetched.status);
    }
    let payload = {};
    try { payload = JSON.parse(fetched.text || '{}'); } catch (e) {
      throw new Error('Graph response was not JSON');
    }
    if (payload.error) throw new Error(payload.error.message || payload.error.code || 'Graph error');
    return Array.isArray(payload.value) ? payload.value : [];
  };

  let pages = await loadPages(bearer);
  if (pages.some((page) => page.status === 401)) {
    const entry = await tokenFor(contextKey);
    const refreshed = await refreshToken(win, userContextId, contextKey, entry, clientId);
    bearer = refreshed?.accessToken || '';
    if (!bearer) throw reconnectError();
    pages = await loadPages(bearer);
  }
  const messages = pages.flatMap(readPage);
  debugLog('Outlook Graph', pages.map((page) => page.status).join(','), messages.length);
  return graphUnreadRows({ value: messages }, CONFIG.MAX_EMAILS);
}

// Outlook web only marks a message read on view when its "mark as read"
// setting allows it; the default waits for the selection to change.
// Returns 'ok', 'scope' (token lacks Mail.ReadWrite), or 'failed'.
export async function markOutlookRead(app, tab, contextKey, messageId) {
  const id = String(messageId || '').trim();
  if (!id) return 'failed';
  const clientId = readOutlookClientId();
  if (outlookClientState(clientId) !== 'ok') return 'failed';

  const win = app.window;
  const userContextId = getTabUserContextId(tab);
  const accountKey = outlookAccountId(contextKey);
  let bearer = await accessToken(win, userContextId, contextKey, clientId);
  if (!bearer) return 'failed';

  const send = (token) => httpRequest(win, {
    url: graphMessageUrl(id),
    userContextId,
    method: 'PATCH',
    anonymous: true,
    headers: {
      Authorization: 'Bearer ' + token,
      Accept: 'application/json'
    },
    body: '{"isRead":true}',
    contentType: 'application/json',
    maxBytes: 200000
  });

  let fetched = await send(bearer);
  if (fetched.status === 401) {
    const entry = await tokenFor(contextKey);
    const refreshed = await refreshToken(win, userContextId, contextKey, entry, clientId);
    bearer = refreshed?.accessToken || '';
    if (!bearer) return 'failed';
    fetched = await send(bearer);
  }
  if (fetched.status === 403) {
    await setAccountMessage(accountKey, 'Reconnect Outlook so opened mail is marked read');
    console.warn('[Zen Integrations] Outlook mark-read was refused (403). Add Mail.ReadWrite to the Entra app, then Connect again.');
    return 'scope';
  }
  if (fetched.status < 200 || fetched.status >= 300) {
    console.warn('[Zen Integrations] Outlook mark-read failed with HTTP', fetched.status);
    return 'failed';
  }
  debugLog('Outlook marked read', id);
  return 'ok';
}
