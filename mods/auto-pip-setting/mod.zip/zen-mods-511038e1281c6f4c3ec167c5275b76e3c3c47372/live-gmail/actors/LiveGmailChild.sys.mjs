const SCAN_DEBOUNCE_MS = 500;

export class LiveGmailChild extends JSWindowActorChild {
  #observer = null;
  #scanTimeout = null;
  #lastReadKey = '';

  handleEvent(event) {
    if (event.type !== 'DOMContentLoaded' && event.type !== 'pageshow') return;
    if (this.#reportFeed()) return;
    this.#setupObserver();
  }

  #reportFeed() {
    const doc = this.document;
    const win = this.contentWindow;
    if (!doc || !win) return false;
    let href = '';
    try {
      href = win.location.href || '';
    } catch (e) {
      return false;
    }
    if (!/\/feed\/atom/i.test(href)) return false;

    const root = doc.documentElement?.localName || '';
    const contentType = doc.contentType || '';
    const isFeed = root === 'feed';
    let text = '';
    if (isFeed) {
      try {
        text = new win.XMLSerializer().serializeToString(doc);
      } catch (e) {}
    }
    try {
      this.sendAsyncMessage('LiveGmail:FeedDocument', {
        href,
        text,
        contentType,
        root,
        signin: !isFeed || /accounts\.google\.com|ServiceLogin/i.test(href)
      });
    } catch (e) {}
    return true;
  }

  didDestroy() {
    try {
      this.#observer?.disconnect();
    } catch (e) {}
    this.#observer = null;
    const win = this.contentWindow;
    if (win && this.#scanTimeout) {
      win.clearTimeout(this.#scanTimeout);
    }
  }

  #isGmail() {
    try {
      return this.contentWindow?.location?.hostname === 'mail.google.com';
    } catch (e) {
      return false;
    }
  }

  #readStateKey() {
    const rows = this.document?.querySelectorAll('tr.zA, tr[role="row"], div[role="row"]') || [];
    const parts = [];
    for (const row of rows) {
      const unread = row.classList.contains('zE') || row.getAttribute('data-is-read') === 'false';
      const id = row.getAttribute('data-legacy-thread-id') || row.getAttribute('data-thread-id') || '';
      parts.push((unread ? 'u' : 'r') + id);
    }
    return String(rows.length) + ':' + parts.join(',');
  }

  receiveMessage(message) {
    if (message.name !== 'LiveGmail:FetchAtom') return null;
    return this.#fetchAtom();
  }

  #feedUrlFromDocument() {
    const win = this.contentWindow;
    const href = win?.location?.href || '';
    const url = new win.URL(href);
    if (url.protocol !== 'https:' || url.hostname !== 'mail.google.com') {
      throw new Error('Gmail feed requires a paired Gmail tab');
    }
    const account = url.pathname.match(/\/mail\/u\/(\d+)(?:\/|$)/)?.[1] || '0';
    return 'https://mail.google.com/mail/u/' + account + '/feed/atom';
  }

  #fetchAtom() {
    const win = this.contentWindow;
    if (!win?.XMLHttpRequest) {
      return Promise.reject(new Error('Gmail tab not ready'));
    }
    let feedUrl;
    try {
      feedUrl = this.#feedUrlFromDocument();
    } catch (e) {
      return Promise.reject(e);
    }

    return new Promise((resolve, reject) => {
      let xhr;
      try {
        xhr = new win.XMLHttpRequest();
      } catch (e) {
        reject(e);
        return;
      }
      try { xhr.mozBackgroundRequest = true; } catch (e) {}
      try { xhr.open('GET', feedUrl, true); } catch (e) { reject(e); return; }
      try { xhr.withCredentials = true; } catch (e) {}
      xhr.onload = () => {
        try {
          resolve({
            status: xhr.status,
            finalUrl: xhr.responseURL || feedUrl,
            text: xhr.responseText ?? '',
            feedUrl
          });
        } catch (e) {
          reject(e);
        }
      };
      xhr.onerror = () => reject(new Error('Network error'));
      xhr.onabort = () => reject(new Error('Aborted'));
      xhr.ontimeout = () => reject(new Error('Timeout'));
      try { xhr.timeout = 8000; } catch (e) {}
      try { xhr.send(); } catch (e) { reject(e); }
    });
  }

  #maybeNotify() {
    if (!this.#isGmail()) return;
    const key = this.#readStateKey();
    if (key === this.#lastReadKey) return;
    this.#lastReadKey = key;
    try {
      this.sendAsyncMessage('LiveGmail:ReadState', { key });
    } catch (e) {}
  }

  #setupObserver() {
    if (!this.#isGmail()) return;
    const win = this.contentWindow;
    const doc = this.document;
    if (!win || !doc) return;

    try {
      this.#observer?.disconnect();
    } catch (e) {}

    const target = doc.querySelector('div[role="main"]') || doc.body;
    if (!target) {
      win.setTimeout(() => this.#setupObserver(), 1000);
      return;
    }

    this.#observer = new win.MutationObserver(() => {
      if (this.#scanTimeout) win.clearTimeout(this.#scanTimeout);
      this.#scanTimeout = win.setTimeout(() => this.#maybeNotify(), SCAN_DEBOUNCE_MS);
    });
    this.#observer.observe(target, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
    this.#maybeNotify();
  }
}
