# Live Gmail Panel Userscript

A userscript for Zen browser that displays Gmail inbox emails in a floating panel when hovering over Gmail essential tabs.

## Features

- Displays the last 20 emails from your Gmail inbox
- Appears as a floating panel when hovering over Gmail essential tabs
- Styled to match Zen browser's native UI
- Click on emails to open them in the Gmail tab

## License

This userscript is provided as-is for use with Zen browser.

