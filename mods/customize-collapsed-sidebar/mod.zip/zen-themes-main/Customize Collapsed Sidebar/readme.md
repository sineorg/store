# Customize Collapsed Sidebar

This mod allows for extensive customization of the collapsed sidebar. By default, it sets everything to the pre-1.13b sizing, but you can adjust most things to your liking!

Do note that this will break when folders are released, I will work on updating this when they are.

Install with [Sine](https://github.com/CosmoCreeper/Sine) for easy customization!

You can also paste the code in your user chrome and it should just work as is!

You can tweak the options via the sine mod settings, or in about:config by looking for mod.ccs options!

![Screenshot](Compact%20Collapsed%20Sidebar.png)
