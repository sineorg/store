# Zen Themes

A collection of every zen theme/mod I've made!

Here's a quick summary:
- Customize Collapsed Sidebar: Make the collapsed sidebar look exactly how you want it to!
  ![Screenshot](Customize%20Collapsed%20Sidebar/Compact%20Collapsed%20Sidebar.png)
