This mod allows you to split tabs by drag and drop links
