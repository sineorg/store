# render.js

**Makes Zen feel alive.**

---

render.js is not a theme.
it doesn’t try to redesign your browser.

it changes how it *behaves*.

small interactions become expressive.
motion feels intentional.
the interface stops being static — and starts responding.

---

## what it does

* dynamic workspace fan switcher
* reactive workspace indicators (time, context, state)
* playful new tab interactions (hover text, subtle variation)
* smarter layout behavior (like masonry essentials)
* ambient motion and micro-interactions across the UI

nothing loud.
nothing intrusive.

just… a different feel.

---