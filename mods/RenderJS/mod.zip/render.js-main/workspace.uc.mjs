console.log("Workspace Fan: loaded");

(function () {
  function layoutFan(button) {
    const items = [...button.querySelectorAll("toolbarbutton:not([active='true'])")];
    const count = items.length;
  
    // ===== DYNAMIC PARAMETERS =====
    const baseArc = Math.PI * 0.6;      // starting arc (~108°)
    const arcGrowth = Math.PI * 0.08;   // how much arc grows per item
    const maxArc = Math.PI * 0.95;      // cap (~170°)
  
    const baseRadius = 32;
    const radiusGrowth = 2.5;
  
    // ===== COMPUTE VALUES =====
    const arc = Math.min(baseArc + count * arcGrowth, maxArc);
    const radius = baseRadius + count * radiusGrowth;
  
    const startAngle = -Math.PI / 2 - arc / 2;
    const endAngle   = -Math.PI / 2 + arc / 2;
  
    items.forEach((el, i) => {
      const angle =
        count === 1
          ? -Math.PI / 2
          : startAngle + ((i + 0.5) / count) * (endAngle - startAngle);
  
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
  
      el.style.transform = `translate(${x}px, ${y}px) scale(1)`;
    });
  }

  function resetFan(button) {
    const items = button.querySelectorAll("toolbarbutton");
    items.forEach(el => {
      el.style.transform = "";
    });
  }

  function initFanFix() {
    const button = document.getElementById("zen-workspaces-button");
    if (!button) return;

    let hadOverflow = false;
    let leaveTimeout = null;

    // ===== OPEN =====
    button.addEventListener("mouseenter", () => {
      if (leaveTimeout) {
        clearTimeout(leaveTimeout);
        leaveTimeout = null;
      }

      if (button.hasAttribute("icons-overflow")) {
        hadOverflow = true;
        button.removeAttribute("icons-overflow");
      }

      requestAnimationFrame(() => layoutFan(button));
      shiftMiniPlayer(true);
    });

    // ===== CLOSE =====
    button.addEventListener("mouseleave", () => {
      resetFan(button);

      leaveTimeout = setTimeout(() => {
        if (hadOverflow) {
          button.setAttribute("icons-overflow", "true");
          hadOverflow = false;
        }
      }, 500); // matches CSS timing
      
      shiftMiniPlayer(false);
    });
    
    const workspaceObserver = new MutationObserver(() => {
      // re-layout whenever active changes
      if (button.matches(":hover")) {
        requestAnimationFrame(() => layoutFan(button));
      }
    });
    
    workspaceObserver.observe(button, {
      attributes: true,
      subtree: true,
      attributeFilter: ["active"]
    });
  }

  // wait for Zen UI
  const observer = new MutationObserver(() => {
    const btn = document.getElementById("zen-workspaces-button");
    if (btn) {
      initFanFix();
      observer.disconnect();
    }
  });

  observer.observe(document, { childList: true, subtree: true });
  
  function shiftMiniPlayer(up = true) {
    const mini = document.getElementById("zen-media-controls-toolbar");
    if (!mini) return;
  
    if (up) {
      mini.style.transition = "transform 0.35s cubic-bezier(0.22, 1, 0.36, 1)";
      mini.style.transform = "translateY(-60px)";
    } else {
      mini.style.transform = "";
    }
  }
})();