# Advanced Tab Groups  

The best tab groups for Zen Browser

<p align="center">
  <img width="161" height="325" alt="image" src="https://github.com/user-attachments/assets/fdcb26fd-548c-40eb-b682-0e6afc95a0cb" />
  <img width="325" alt="Advanced Tab Groups Video" src="https://github.com/user-attachments/assets/37a5bc34-6b87-4ce2-900c-2e2c5ebfc125" />
</p>

---
## Acknowledgements
Thank you to everyone for motivating me to keep this project going! Could not do it without you!

<img src="https://github.com/heyitszenithyt/zen-browser-badges/raw/fb14dcd72694b7176d141c774629df76af87514e/light/zen-badge-light.png" alt="Made For Zen Badge">
