# Tab Explode Animation for Zen

## Overview

This UserScript adds a fun, visual "bubble explosion" animation when a tab or a tab group is closed in Zen. Instead of just disappearing, the closed tab or group will burst into a configurable number of small bubbles that animate outwards (Deta Surf inspired).



