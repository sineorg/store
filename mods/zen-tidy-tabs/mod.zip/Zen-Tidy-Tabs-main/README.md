# Tidy Tabs
Sort your tabs using Firefox's local AI but make it look awesome! Includes ATG install.
<p align="center">
  <img width="164" height="1020" alt="image" src="https://github.com/user-attachments/assets/88ca1f8c-182c-459b-8a7a-e596b8e833c0" />
</p>
