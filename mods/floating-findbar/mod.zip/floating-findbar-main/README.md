# Floating Findbar
A floating findbar with opening and closing animation for Zen

![img](https://raw.githubusercontent.com/qumeqa/floating-findbar/refs/heads/main/cover.png)