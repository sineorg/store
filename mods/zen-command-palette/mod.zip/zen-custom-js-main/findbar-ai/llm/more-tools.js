import { debugLog, debugError } from "../prefs.js";

// ────────────────── more function which llms can use ───────────────
