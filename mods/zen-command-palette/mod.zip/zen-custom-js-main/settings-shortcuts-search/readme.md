# Zen Browser Keyboard Shortcuts Search

A lightweight userscript for Zen Browser that adds a search and filter functionality to keyboard shortcuts settings page.

## Features

- Search keyboard shortcuts
- Filter shortcuts by group
- Dynamic filtering with live search
- Minimal and simple implementation

## Demo

https://github.com/user-attachments/assets/01b14b7b-04a7-49d8-a719-83ad7fc8c603
