// ==UserScript==
// @include   main
// @ignorecache
// ==/UserScript==

/*

Natsumi Browser - Welcome to your personal internet.

Copyright (c) 2024-present Green (@greeeen-dev)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

window.addEventListener("DOMContentLoaded", (event) => {
    let targetDoc = event.target;

    if (targetDoc.URL === "about:robots") {
        try {
            let robotsButton = targetDoc.getElementById("errorTryAgain");
            robotsButton.addEventListener("click", () => {
                if (robotsButton.hasAttribute("natsumi-easter-egg")) {
                    // >:3
                    targetDoc.defaultView.location.href = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";
                } else {
                    robotsButton.setAttribute("natsumi-easter-egg", "");
                }
            });
        } catch(e) {
            console.error(e);
        }
    }
});