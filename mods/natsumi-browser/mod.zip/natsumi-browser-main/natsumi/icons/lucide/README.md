# Lucide icons
Natsumi uses Lucide icons as an icon pack. [View license](./LICENSE)

- [Website](https://lucide.dev)
- [GitHub](https://github.com/lucide-icons/lucide)