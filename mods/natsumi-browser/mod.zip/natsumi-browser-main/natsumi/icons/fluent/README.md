# Microsoft Fluent UI icons
Natsumi uses Microsoft Fluent UI icons as an icon pack. [View license](./LICENSE)