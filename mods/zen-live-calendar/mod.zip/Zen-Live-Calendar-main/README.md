# Zen-Live-Calendar
Brings the live folder functionality from Arc to Zen, making it feel as native as possible.


## How to use
1. Install [Sine](https://github.com/CosmoCreeper/Sine)
2. Locate the Live Calendar mod in the Sine store
3. Install Live Calendar
4. Ensure you have a Google Essential Tab pinned
5. Open google calendar
6. On the left, click on the three dots of the Calendar you would like to import
7. Click "Settings and sharing"
8. Scroll the the bottom and locate the "Secret adress in iCal format"
9. Copy the URL
10. Hover over the Google Calendar Essential
11. Go to Calendar Settings -> paste ICS URL from clipboard
12. click that button
Hover back over the tab and see your events! You will also be notified 5 minutes in advace of any meetings linked to the event! IF you close the popup, it will reapear 30s before the meeting starts as a reminder!
