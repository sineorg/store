# Firefox Smooth Vertical Tabs Animation
![](./image.png)

Small mod that fixes the tab bar so it expands smoothly on hover.
