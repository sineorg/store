# Zen-Tidy-Downloads

![image](https://github.com/Anoms12/Zen-Tidy-Downloads/blob/main/image.png?raw=true)

**Rename your downloads with ease, and do it in style!**

## Features
* AI renaming
* Undo button if when you don't like the name

That's all, your just downloading a file. _What did you expect?_
