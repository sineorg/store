// ==UserScript==
// @include   main
// @loadOrder 99999999999998
// @ignorecache
// ==/UserScript==

// zen-stuff.uc.js
// Dismissed downloads pile with messy-to-grid transition
(function () {
  "use strict";

  // Wait for browser window to be ready
  if (location.href !== "chrome://browser/content/browser.xhtml") return;

  const Utils = window.zenTidyDownloadsUtils;
  if (!Utils) {
    console.error("[Zen Stuff] zenTidyDownloadsUtils not loaded - ensure tidy-downloads-utils.uc.js loads first (check @loadOrder in headers)");
    return;
  }

  // Single-flight: avoid duplicate pile registration if this script is evaluated twice.
  if (window.__zenStuffPileBundleExecuted) {
    console.warn("[Zen Stuff] Bundle already executed in this window; skipping duplicate load.");
    return;
  }
  window.__zenStuffPileBundleExecuted = true;
  const {
    validateFilePathOrThrow,
    validatePodData,
    formatBytes,
    waitForElement,
    IMAGE_EXTENSIONS,
    TEXT_EXTENSIONS,
    SYSTEM_ICON_EXTENSIONS,
    readTextFilePreview,
    filenameEndsWithExtensionFromSet
  } = Utils;

  // Configuration
  const CONFIG = {
    maxPileSize: 20, // Maximum pods to keep in pile
    pileDisplayCount: 20, // Pods visible in messy pile
    gridAnimationDelay: 15, // ms between pod animations
    hoverDebounceMs: 50, // Hover debounce delay
    pileRotationRange: 8, // degrees ±
    pileOffsetRange: 8, // pixels ±
    gridPadding: 12, // pixels between grid items
    minPodSize: 45, // minimum pod size in grid
    minSidePadding: 5, // minimum padding from sidebar edges
    animationDuration: 150, // pod transition duration
    containerAnimationDuration: 80, // container height/padding transition duration
    maxRetryAttempts: 10, // Maximum initialization retry attempts
    retryDelay: 500, // Delay between retry attempts
  };

  // Firefox preferences
  const PREFS = {
    alwaysShowPile: 'zen.stuff-pile.always-show', // Boolean: show pile always (hide with Alt key)
    useLibraryButton: 'zen.tidy-downloads.use-library-button', // Boolean: use zen-library-button instead of downloads-button
  };

  // Centralized state management
  class PileState {
    constructor() {
      this.downloadButton = null;
      this.pileContainer = null;
      this.dynamicSizer = null;
      this.hoverBridge = null;
      // Removed isGridMode - always single column mode
      this.hoverTimeout = null;
      this.dismissedPods = new Map(); // podKey -> podData
      this.podElements = new Map(); // podKey -> DOM element
      this.pilePositions = new Map(); // podKey -> {x, y, rotation, zIndex}
      this.gridPositions = new Map(); // podKey -> {x, y, row, col}
      this.isInitialized = false;
      this.isTransitioning = false;
      this.isAltPressed = false;
      this.currentZenSidebarWidthForPile = '';
      this.retryCount = 0;
      this.eventListeners = new Map(); // Track event listeners for cleanup
      this.prefObserver = null;
      // --- add pendingPileClose flag ---
      this.pendingPileClose = false;
      // --- add gridScrollIndex for grid windowing ---
      this.gridScrollIndex = 0;
      // --- add visibleGridOrder for carousel ---
      this.visibleGridOrder = [];
      // --- add carouselStartIndex for >6 pods ---
      this.carouselStartIndex = 0;
      // --- add isGridAnimating flag ---
      this.isGridAnimating = false;
      // --- add workspaceScrollboxStyle for controlling ::after opacity ---
      this.workspaceScrollboxStyle = null;
      // --- add isEditing flag to prevent pile from hiding during rename ---
      this.isEditing = false;
      // --- add recentlyRemoved flag to prevent pile from hiding immediately after removal ---
      this.recentlyRemoved = false;
      // --- add mediaToolbarMaskRemovalTimeout for delayed mask removal on pile collapse ---
      this.mediaToolbarMaskRemovalTimeout = null;
      // --- true from row contextmenu until popuphidden (covers gap before menupopup.state === 'open') ---
      this.pileContextMenuActive = false;
      // --- sticky / mask layout repair (coalesced) ---
      this.pileRepairDebounceId = null;
      this.lastPileRepairAt = 0;
      this.pileLayoutRepairIntervalId = null;
    }

    // Safe getters with validation
    getPodData(key) {
      return this.dismissedPods.get(key) || null;
    }

    getPodElement(key) {
      return this.podElements.get(key) || null;
    }

    getPilePosition(key) {
      return this.pilePositions.get(key) || null;
    }

    getGridPosition(key) {
      return this.gridPositions.get(key) || null;
    }

    // Safe setters with validation
    setPodData(key, data) {
      if (key && data) {
        this.dismissedPods.set(key, data);
      }
    }

    setPodElement(key, element) {
      if (key && element) {
        this.podElements.set(key, element);
      }
    }

    // Cleanup methods
    removePod(key) {
      this.dismissedPods.delete(key);
      this.podElements.delete(key);
      this.pilePositions.delete(key);
      this.gridPositions.delete(key);
    }

    clearAll() {
      this.dismissedPods.clear();
      this.podElements.clear();
      this.pilePositions.clear();
      this.gridPositions.clear();
    }
  }

  // Global state instance
  const state = new PileState();

  // Error handling utilities (validateFilePath, validatePodData: see tidy-downloads-utils.uc.js)
  class ErrorHandler {
    static handleError(error, context, fallback = null) {
      console.error(`[Dismissed Pile] Error in ${context}:`, error);
      return fallback;
    }

    static async withRetry(operation, maxAttempts = 3, delay = 1000) {
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          return await operation();
        } catch (error) {
          if (attempt === maxAttempts) {
            throw error;
          }
          console.warn(`[Dismissed Pile] Attempt ${attempt} failed, retrying in ${delay}ms:`, error);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
  }

  // Text-file preview toggle for dismissed pods (disabled by default). Images always get previews.
  let zenStuffFilePreviewEnabled = false;
  try {
    if (typeof Services !== "undefined" && Services.prefs) {
      // Opt-in for text-file previews; images always show regardless.
      zenStuffFilePreviewEnabled = Services.prefs.getBoolPref("extensions.downloads.enable_file_preview", false);
    }
  } catch (e) {
    // Fallback to disabled if prefs are unavailable
    zenStuffFilePreviewEnabled = false;
  }

  // File system utilities with proper error handling
  class FileSystem {
    static async createFileInstance(path) {
      try {
        const validatedPath = validateFilePathOrThrow(path);
        const file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsIFile);
        file.initWithPath(validatedPath);
        return file;
      } catch (error) {
        throw new Error(`Failed to create file instance: ${error.message}`);
      }
    }

    static async fileExists(path) {
      try {
        const file = await this.createFileInstance(path);
        return file.exists();
      } catch (error) {
        console.warn(`[FileSystem] Error checking file existence: ${error.message}`);
        return false;
      }
    }

    static async getParentDirectory(path) {
      try {
        const file = await this.createFileInstance(path);
        return file.parent;
      } catch (error) {
        throw new Error(`Failed to get parent directory: ${error.message}`);
      }
    }

    // Auto-increment filename if duplicate exists
    static async getAvailableFilename(parentDir, baseName, ext) {
      let candidate = baseName + ext;
      let counter = 1;
      let file = parentDir.clone();
      file.append(candidate);
      while (file.exists()) {
        candidate = `${baseName} (${counter})${ext}`;
        file = parentDir.clone();
        file.append(candidate);
        counter++;
      }
      return candidate;
    }

    static async renameFile(oldPath, newFilename) {
      try {
        const oldFile = await this.createFileInstance(oldPath);
        if (!oldFile.exists()) {
          throw new Error('Source file does not exist');
        }

        const parentDir = oldFile.parent;
        // Split newFilename into base and extension
        const dotIdx = newFilename.lastIndexOf('.');
        let baseName = newFilename;
        let ext = '';
        if (dotIdx > 0) {
          baseName = newFilename.substring(0, dotIdx);
          ext = newFilename.substring(dotIdx);
        }
        // Find available filename
        const availableName = await this.getAvailableFilename(parentDir, baseName, ext);
        const newFile = parentDir.clone();
        newFile.append(availableName);
        oldFile.moveTo(parentDir, availableName);
        return newFile.path;
      } catch (error) {
        throw new Error(`Failed to rename file: ${error.message}`);
      }
    }

    static async deleteFile(path) {
      try {
        const file = await this.createFileInstance(path);
        if (file.exists()) {
          file.remove(false); // false = don't move to trash
          return true;
        }
        return false;
      } catch (error) {
        throw new Error(`Failed to delete file: ${error.message}`);
      }
    }
  }

  // Event management with cleanup
  class EventManager {
    static addEventListener(element, event, handler, options = {}) {
      if (!element || !handler) {
        console.warn('[EventManager] Invalid element or handler for event listener');
        return;
      }

      element.addEventListener(event, handler, options);

      // Track for cleanup
      const key = `${element.id || 'unknown'}-${event}`;
      if (!state.eventListeners.has(key)) {
        state.eventListeners.set(key, []);
      }
      state.eventListeners.get(key).push({ element, event, handler, options });
    }

    static removeEventListener(element, event, handler) {
      if (!element || !handler) return;

      element.removeEventListener(event, handler);

      // Remove from tracking
      const key = `${element.id || 'unknown'}-${event}`;
      const listeners = state.eventListeners.get(key);
      if (listeners) {
        const index = listeners.findIndex(l => l.handler === handler);
        if (index !== -1) {
          listeners.splice(index, 1);
        }
      }
    }

    static cleanupAll() {
      for (const [key, listeners] of state.eventListeners) {
        for (const { element, event, handler } of listeners) {
          try {
            element.removeEventListener(event, handler);
          } catch (error) {
            console.warn(`[EventManager] Error removing event listener: ${error.message}`);
          }
        }
      }
      state.eventListeners.clear();
    }
  }

  // Debug logging with conditional output
  function debugLog(message, data = null) {
    // Only log in development mode or when explicitly enabled
    if (typeof window.zenDebugMode !== 'undefined' && window.zenDebugMode) {
      try {
        console.log(`[Dismissed Pile] ${message}`, data || '');
      } catch (e) {
        console.log(`[Dismissed Pile] ${message}`);
      }
    }
  }

  // Debug function to test preference (call from browser console)
  window.testLibraryButtonPref = function() {
    console.log("=== Testing Library Button Preference ===");
    console.log(`Preference name: ${PREFS.useLibraryButton}`);
    
    try {
      const value = Services.prefs.getBoolPref(PREFS.useLibraryButton, false);
      console.log(`Current preference value: ${value}`);
    } catch (e) {
      console.log(`Error reading preference:`, e);
    }
    
    const libraryBtn = document.getElementById('zen-library-button');
    const downloadsBtn = document.getElementById('downloads-button');
    console.log(`zen-library-button exists: ${!!libraryBtn}`);
    console.log(`downloads-button exists: ${!!downloadsBtn}`);
    console.log(`Current state.downloadButton:`, state.downloadButton);
    
    // Test waiting for zen-library-button
    console.log("Testing waitForElement for zen-library-button...");
    waitForElement('zen-library-button', 3000).then(element => {
      console.log(`waitForElement result:`, element);
    });
    
    // Test re-finding the button
    console.log("Re-finding button...");
    findDownloadButton().then(() => {
      console.log(`After re-find, state.downloadButton:`, state.downloadButton);
    }).catch(e => console.error("Error re-finding:", e));
  };

  // Initialize the pile system with proper error handling
  async function init() {
    if (state.isInitialized) {
      return;
    }
    if (window.__zenStuffPileInitInProgress) {
      debugLog("init skipped: already in progress (single-flight)");
      return;
    }
    window.__zenStuffPileInitInProgress = true;

    debugLog("Initializing dismissed downloads pile system");

    try {
      // Check retry limit
      if (state.retryCount >= CONFIG.maxRetryAttempts) {
        console.error('[Dismissed Pile] Max retry attempts reached, initialization failed');
        return;
      }

      // Wait for the main download script to be available
      if (!window.zenTidyDownloads) {
        state.retryCount++;
        debugLog(`Main download script not ready, retry ${state.retryCount}/${CONFIG.maxRetryAttempts}`);
        setTimeout(init, CONFIG.retryDelay);
        return;
      }

      // Wait for SessionStore to be ready
      await initSessionStore();

      await ErrorHandler.withRetry(async () => {
        await findDownloadButton();
        await createPileContainer();
        setupEventListeners();
        loadExistingDismissedPods();
      });

      state.isInitialized = true;
      state.retryCount = 0; // Reset retry count on success
      debugLog("Dismissed downloads pile system initialized successfully");
    } catch (error) {
      ErrorHandler.handleError(error, 'initialization');
      state.retryCount++;
      setTimeout(init, CONFIG.retryDelay);
    } finally {
      window.__zenStuffPileInitInProgress = false;
    }
  }

  // Initialize SessionStore and wait for it to be ready
  async function initSessionStore() {
    if (!window.SessionStore) {
      console.warn("[Dismissed Pile] SessionStore not available, retrying...");
      await new Promise(resolve => setTimeout(resolve, 200));
      return initSessionStore();
    }

    try {
      if (window.SessionStore.promiseInitialized) {
        await window.SessionStore.promiseInitialized;
      }
      debugLog("[SessionStore] SessionStore initialized and ready");
    } catch (error) {
      console.error("[Dismissed Pile] Error initializing SessionStore:", error);
    }
  }

  // Save dismissed pod to SessionStore
  function saveDismissedPodToSession(podData) {
    try {
      if (!window.SessionStore) {
        console.warn("[Dismissed Pile] SessionStore not available for saving");
        return;
      }

      // Serialize pod data (exclude DOM elements and functions)
      const serializedData = {
        key: podData.key,
        filename: podData.filename,
        originalFilename: podData.originalFilename,
        fileSize: podData.fileSize,
        contentType: podData.contentType,
        targetPath: podData.targetPath,
        downloadId: podData.downloadId,
        sourceUrl: podData.sourceUrl,
        startTime: podData.startTime,
        endTime: podData.endTime,
        dismissTime: podData.dismissTime,
        wasRenamed: podData.wasRenamed,
        previewData: podData.previewData,
        dominantColor: podData.dominantColor
      };

      SessionStore.setCustomWindowValue(
        window,
        `zen-stuff-pod-${podData.key}`,
        JSON.stringify(serializedData)
      );

      debugLog(`[SessionStore] Saved pod to session: ${podData.key}`);
    } catch (error) {
      console.error("[Dismissed Pile] Error saving pod to SessionStore:", error);
    }
  }

  // Remove dismissed pod from SessionStore
  function removeDismissedPodFromSession(podKey) {
    try {
      if (!window.SessionStore) {
        console.warn("[Dismissed Pile] SessionStore not available for removal");
        return;
      }

      SessionStore.deleteCustomWindowValue(window, `zen-stuff-pod-${podKey}`);
      debugLog(`[SessionStore] Removed pod from session: ${podKey}`);
    } catch (error) {
      console.error("[Dismissed Pile] Error removing pod from SessionStore:", error);
    }
  }

  // Restore dismissed pods from SessionStore
  async function restoreDismissedPodsFromSession() {
    try {
      if (!window.SessionStore) {
        console.warn("[Dismissed Pile] SessionStore not available for restoration");
        return;
      }

      // Get the list of pod keys from SessionStore
      const podKeysJson = SessionStore.getCustomWindowValue(window, 'zen-stuff-pod-keys');
      if (!podKeysJson) {
        debugLog("[SessionStore] No saved pod keys found");
        return;
      }

      // SECURITY FIX: Add error handling for JSON.parse
      let podKeys;
      try {
        podKeys = JSON.parse(podKeysJson);
      } catch (error) {
        console.error("[SessionStore] Error parsing pod keys JSON:", error);
        debugLog("[SessionStore] Invalid pod keys JSON, skipping restoration");
        return;
      }

      // Validate podKeys is an array
      if (!Array.isArray(podKeys)) {
        console.error("[SessionStore] Pod keys is not an array:", typeof podKeys);
        debugLog("[SessionStore] Pod keys is not an array, skipping restoration");
        return;
      }

      let restoredCount = 0;
      const restorationPromises = [];

      for (const podKey of podKeys) {
        const restorationPromise = (async () => {
          try {
            const podDataJson = SessionStore.getCustomWindowValue(window, `zen-stuff-pod-${podKey}`);
            if (podDataJson) {
              // SECURITY: Comprehensive data validation for SessionStore
              let podData;
              try {
                podData = JSON.parse(podDataJson);
              } catch (error) {
                console.error(`[SessionStore] Error parsing pod data JSON for key ${podKey}:`, error);
                debugLog(`[SessionStore] Invalid pod data JSON for ${podKey}, skipping`);
                return;
              }

              // SECURITY: Validate pod data structure and content
              if (!podData || typeof podData !== 'object') {
                console.error(`[SessionStore] Invalid pod data type for key ${podKey}:`, typeof podData);
                debugLog(`[SessionStore] Pod data is not an object for ${podKey}, skipping`);
                return;
              }

              // Validate required fields
              const requiredFields = ['key', 'filename', 'targetPath'];
              const missingFields = requiredFields.filter(field => !podData[field]);
              if (missingFields.length > 0) {
                console.error(`[SessionStore] Missing required fields for ${podKey}:`, missingFields);
                debugLog(`[SessionStore] Pod data missing required fields: ${missingFields.join(', ')}, skipping`);
                return;
              }

              // Validate field types
              if (typeof podData.key !== 'string' || podData.key.length === 0) {
                console.error(`[SessionStore] Invalid key field for ${podKey}`);
                return;
              }
              if (typeof podData.filename !== 'string' || podData.filename.length === 0) {
                console.error(`[SessionStore] Invalid filename field for ${podKey}`);
                return;
              }
              if (typeof podData.targetPath !== 'string' || podData.targetPath.length === 0) {
                console.error(`[SessionStore] Invalid targetPath field for ${podKey}`);
                return;
              }

              // SECURITY: Validate path before using it
              try {
                validateFilePathOrThrow(podData.targetPath);
              } catch (pathError) {
                console.error(`[SessionStore] Invalid path in stored data for ${podKey}:`, pathError.message);
                debugLog(`[SessionStore] Path validation failed for ${podKey}, skipping`);
                return;
              }

              // Validate numeric fields if present
              if (podData.fileSize !== undefined && (typeof podData.fileSize !== 'number' || podData.fileSize < 0)) {
                console.warn(`[SessionStore] Invalid fileSize for ${podKey}, resetting to 0`);
                podData.fileSize = 0;
              }

              // Validate previewData structure if present
              if (podData.previewData !== null && podData.previewData !== undefined) {
                if (typeof podData.previewData !== 'object') {
                  console.warn(`[SessionStore] Invalid previewData type for ${podKey}, clearing`);
                  podData.previewData = null;
                } else if (podData.previewData.type === 'image' && !podData.previewData.src) {
                  console.warn(`[SessionStore] Image previewData missing src for ${podKey}, clearing`);
                  podData.previewData = null;
                }
              }

              // Verify the file still exists before restoring
              let actualPath = podData.targetPath;
              let exists = await FileSystem.fileExists(actualPath);

              console.log(`[SessionStore] Checking file existence for ${podData.filename}: saved path=${podData.targetPath}, exists=${exists}`);

              // If file doesn't exist at saved path, try to find it with current filename
              if (!exists && podData.filename) {
                try {
                  const parentDir = await FileSystem.getParentDirectory(podData.targetPath);
                  console.log(`[SessionStore] Parent directory exists: ${parentDir && parentDir.exists()}`);

                  if (parentDir && parentDir.exists()) {
                    const newFile = parentDir.clone();
                    newFile.append(podData.filename);
                    const newPath = newFile.path;
                    const newExists = newFile.exists();

                    console.log(`[SessionStore] Trying new path: ${newPath}, exists=${newExists}`);

                    if (newExists) {
                      actualPath = newPath;
                      exists = true;
                      podData.targetPath = actualPath; // Update the saved path
                      console.log(`[SessionStore] Found file with updated path: ${podData.filename} -> ${actualPath}`);

                      // Also save the updated path back to SessionStore
                      saveDismissedPodToSession(podData);
                    } else {
                      console.log(`[SessionStore] File not found with current filename: ${podData.filename}`);
                    }
                  }
                } catch (error) {
                  console.warn(`[SessionStore] Error checking for file with current filename:`, error);
                }
              }

              if (exists) {
                console.log(`[SessionStore] File exists, checking if image regeneration needed. ContentType: "${podData.contentType}", filename: ${podData.filename}`);

                // Always regenerate image preview for image files to ensure correct path
                const hasImageContentType = podData.contentType && podData.contentType !== "null" && podData.contentType.startsWith('image/');
                const hasImageExtension = podData.filename && /\.(jpg|jpeg|png|gif|bmp|webp|svg|ico)$/i.test(podData.filename);
                const isImage = hasImageContentType || hasImageExtension;

                console.log(`[SessionStore] Image detection - contentType: "${podData.contentType}", hasImageContentType: ${hasImageContentType}, hasImageExtension: ${hasImageExtension}, isImage: ${isImage}`);

                if (isImage) {
                  console.log(`[SessionStore] Starting image preview regeneration for: ${podData.filename}`);
                  try {
                    const file = await FileSystem.createFileInstance(actualPath);

                    // Try multiple approaches to create a working image URL
                    let fileUrl;

                    // Method 1: Use Services.io.newFileURI (most reliable)
                    if (Services.io && Services.io.newFileURI) {
                      try {
                        fileUrl = Services.io.newFileURI(file).spec;
                        console.log(`[SessionStore] Created file URL using Services.io: ${fileUrl}`);
                      } catch (ioError) {
                        console.warn(`[SessionStore] Services.io.newFileURI failed:`, ioError);
                      }
                    }

                    // Method 2: Manual file URL construction (fallback)
                    if (!fileUrl) {
                      const path = actualPath.replace(/\\/g, '/');
                      fileUrl = 'file:///' + (path.startsWith('/') ? path.substring(1) : path);
                      console.log(`[SessionStore] Created file URL manually: ${fileUrl}`);
                    }

                    podData.previewData = {
                      type: 'image',
                      src: fileUrl
                    };
                    console.log(`[SessionStore] Regenerated image preview for: ${podData.filename}, URL: ${fileUrl}`);
                  } catch (error) {
                    console.error(`[SessionStore] Error regenerating image preview for ${podData.filename}:`, error);
                    // Fall back to icon if image preview fails
                    podData.previewData = null;
                  }
                }

                // Don't call addPodToPile as it would save again, just restore the state
                state.dismissedPods.set(podData.key, podData);

                // Create DOM element
                const podElement = createPodElement(podData);
                state.podElements.set(podData.key, podElement);
                state.pileContainer.appendChild(podElement);

                // Generate position for single column layout
                generateGridPosition(podData.key);
                applyGridPosition(podData.key, 0);

                restoredCount++;
                debugLog(`[SessionStore] Restored pod: ${podData.filename}`);
              } else {
                // File no longer exists, remove from session
                removeDismissedPodFromSession(podKey);
                debugLog(`[SessionStore] File no longer exists, skipping: ${podData.filename}`);
              }
            }
          } catch (error) {
            console.error(`[Dismissed Pile] Error restoring pod ${podKey}:`, error);
          }
        })();

        restorationPromises.push(restorationPromise);
      }

      // Wait for all restorations to complete
      await Promise.all(restorationPromises);

      if (restoredCount > 0) {
        // Update the pod keys list to remove any that failed to restore
        updatePodKeysInSession();

        updatePileVisibility();
        updateDownloadsButtonVisibility();

        // Show pile if in always-show mode
        if (getAlwaysShowPile() && shouldPileBeVisible()) {
          setTimeout(() => showPile(), 100);
        }
      }

      debugLog(`[SessionStore] Restored ${restoredCount} pods from session`);
    } catch (error) {
      console.error("[Dismissed Pile] Error restoring pods from SessionStore:", error);
    }
  }

  // Update the list of pod keys in SessionStore
  function updatePodKeysInSession() {
    try {
      if (!window.SessionStore) return;

      const podKeys = Array.from(state.dismissedPods.keys());
      SessionStore.setCustomWindowValue(
        window,
        'zen-stuff-pod-keys',
        JSON.stringify(podKeys)
      );

      debugLog(`[SessionStore] Updated pod keys list: ${podKeys.length} pods`);
    } catch (error) {
      console.error("[Dismissed Pile] Error updating pod keys in SessionStore:", error);
    }
  }

  // Find the Firefox downloads button with better error handling and retry for custom buttons
  async function findDownloadButton() {
    try {
      // Always try zen-library-button first (auto-detect), regardless of preference.
      // This ensures hover works correctly when zen-library-button replaces the downloads button.
      console.log(`[Zen Stuff] Auto-detecting download button (trying zen-library-button first)...`);
      const libraryButton = await waitForElement('zen-library-button', 2000);

      if (libraryButton) {
        console.log("[Zen Stuff] ✅ Found zen-library-button for hover detection (auto-detected)");
        debugLog("Found zen-library-button for hover detection (auto-detected)");
        state.downloadButton = libraryButton;
        return;
      }
      console.log("[Zen Stuff] zen-library-button not found, trying downloads button...");
      debugLog("zen-library-button not found, falling back to downloads button");
      
      // Optimized selector order - most common first
      const selectors = [
        '#downloads-button',
        '#downloads-indicator',
        '[data-l10n-id="downloads-button"]',
        '.toolbarbutton-1[command="Tools:Downloads"]'
      ];

      for (const selector of selectors) {
        try {
          state.downloadButton = document.querySelector(selector);
          if (state.downloadButton) {
            console.log(`[Zen Stuff] ✅ Found download button using selector: ${selector}`, state.downloadButton);
            debugLog(`Found download button using selector: ${selector}`);
            return;
          }
        } catch (error) {
          console.warn(`[DownloadButton] Error with selector ${selector}:`, error);
        }
      }

      // Fallback: look for any element with downloads-related attributes
      try {
        const fallbackElements = document.querySelectorAll('[id*="download"], [class*="download"]');
        for (const element of fallbackElements) {
          if (element.getAttribute('command')?.includes('Downloads') ||
            element.textContent?.toLowerCase().includes('download')) {
            state.downloadButton = element;
            debugLog("Found download button using fallback method", element);
            return;
          }
        }
      } catch (error) {
        console.warn('[DownloadButton] Error in fallback search:', error);
      }

      throw new Error("Download button not found after all attempts");
    } catch (error) {
      console.error('[DownloadButton] Error finding download button:', error);
      throw error;
    }
  }

  // Create the pile container
  async function createPileContainer() {
    if (!state.downloadButton) throw new Error("Download button not available");

    // Check for existing elements (sizer and hover bridge are siblings — removing sizer alone orphans the bridge)
    let existingSizer = document.getElementById("zen-dismissed-pile-dynamic-sizer");
    if (existingSizer) {
      debugLog("Found existing dynamic sizer, removing it first");
      existingSizer.remove();
    }
    let existingBridge = document.getElementById("zen-dismissed-pile-hover-bridge");
    while (existingBridge) {
      debugLog("Found existing hover bridge, removing it first");
      existingBridge.remove();
      existingBridge = document.getElementById("zen-dismissed-pile-hover-bridge");
    }
    state.hoverBridge = null;

    // Create the dynamic sizer element
    state.dynamicSizer = document.createElement("div");
    state.dynamicSizer.id = "zen-dismissed-pile-dynamic-sizer";

    // Check if we're in compact mode to determine positioning
    const isCompactMode = document.documentElement.getAttribute('zen-compact-mode') === 'true';
    const isSidebarExpanded = document.documentElement.getAttribute('zen-sidebar-expanded') === 'true';

    // Use absolute positioning when integrated into toolbar structure (like media controls)
    // This allows it to integrate properly with compact mode
    const positionType = (isCompactMode && !isSidebarExpanded) ? 'absolute' : 'absolute';

    state.dynamicSizer.style.cssText = `
      position: ${positionType};
      overflow: hidden;
      height: 0px;
      bottom: 35px;
      left: 0px;
      right: 0px;
      background: transparent;
      backdrop-filter: none;
      -webkit-backdrop-filter: none;
      box-sizing: border-box;
      transition: height ${CONFIG.containerAnimationDuration}ms ease, padding-bottom ${CONFIG.containerAnimationDuration}ms ease, padding-left ${CONFIG.containerAnimationDuration}ms ease, background 0.2s ease;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: flex-end;
      padding-bottom: 0px;
      padding-left: 0px;
      z-index: 4;
    `;

    state.pileContainer = document.createElement("div");
    state.pileContainer.id = "zen-dismissed-pile-container";
    state.pileContainer.className = "zen-dismissed-pile";

    state.pileContainer.style.cssText = `
      position: relative;
      z-index: 1;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding-left: 5px;
      padding-right: 5px;
    `;

    // Buttons removed - no longer needed

    // Append pileContainer to dynamicSizer
    state.dynamicSizer.appendChild(state.pileContainer);

    // Create hover bridge to cover the gap between download button and pile (prevents pile from hiding when cursor is in that zone)
    state.hoverBridge = document.createElement("div");
    state.hoverBridge.id = "zen-dismissed-pile-hover-bridge";
    state.hoverBridge.style.cssText = `
      position: absolute;
      bottom: 20px;
      left: 0;
      right: 0;
      height: 28px;
      z-index: 3;
      pointer-events: auto;
      display: none;
      -moz-window-dragging: no-drag;
    `;

    // Setup hover events for background/buttons
    setupPileBackgroundHoverEvents();

    // Insert into browser DOM structure after media controls toolbar for better integration
    // Similar to how notifications attach after the media controls toolbar
    const mediaControlsToolbar = document.getElementById('zen-media-controls-toolbar');
    const zenMainAppWrapper = document.getElementById('zen-main-app-wrapper');

    if (mediaControlsToolbar && mediaControlsToolbar.parentNode) {
      // Insert bridge first (fills gap below pile), then dynamicSizer
      const parent = mediaControlsToolbar.parentNode;
      parent.insertBefore(state.hoverBridge, mediaControlsToolbar.nextSibling);
      parent.insertBefore(state.dynamicSizer, state.hoverBridge.nextSibling);

      // Ensure parent has position: relative for absolute positioning to work correctly
      const parentStyle = window.getComputedStyle(parent);
      if (parentStyle.position === 'static') {
        parent.style.position = 'relative';
        debugLog("Set parent container to position: relative for absolute positioning");
      }

      debugLog("Inserted dismissed pile container after zen-media-controls-toolbar");
    } else if (zenMainAppWrapper) {
      // Fallback: insert into zen-main-app-wrapper
      zenMainAppWrapper.appendChild(state.hoverBridge);
      zenMainAppWrapper.appendChild(state.dynamicSizer);
      debugLog("Inserted dismissed pile container into zen-main-app-wrapper (fallback)");
    } else {
      // Final fallback: append to document.body
      document.body.appendChild(state.hoverBridge);
      document.body.appendChild(state.dynamicSizer);
      debugLog("Inserted dismissed pile container into document.body (final fallback)");
    }

    // Set up observer for compact mode changes
    setupCompactModeObserver();

    // Create style element for controlling workspace-arrowscrollbox::after opacity
    if (!state.workspaceScrollboxStyle) {
      state.workspaceScrollboxStyle = document.createElement('style');
      state.workspaceScrollboxStyle.id = 'zen-stuff-workspace-scrollbox-style';
      state.workspaceScrollboxStyle.textContent = `
        arrowscrollbox.workspace-arrowscrollbox::after {
          opacity: var(--zen-stuff-scrollbox-after-opacity, 1) !important;
        }

        @property --zen-pile-height {
          syntax: "<length>";
          inherits: true;
          initial-value: -50px;
        }

        #zen-tabs-wrapper {
          mask-image: linear-gradient(to top, transparent var(--zen-pile-height), black calc(var(--zen-pile-height) + 50px)) !important;
          transition: --zen-pile-height 100ms ease !important;
        }

        #zen-media-controls-toolbar.zen-pile-expanded {
          mask-image: linear-gradient(to top, transparent 50px, black 150px) !important;
          -webkit-mask-image: linear-gradient(to top, transparent 50px, black 150px) !important;
          mask-size: 100% 100%;
          -webkit-mask-size: 100% 100%;
          transition: mask-image 80ms ease, -webkit-mask-image 80ms ease;
        }
      `;
      document.head.appendChild(state.workspaceScrollboxStyle);
      debugLog("Created arrowscrollbox.workspace-arrowscrollbox::after style control");
    }
  }

  // Setup event listeners
  function setupEventListeners() {
    // Listen for pod dismissals from main script
    window.zenTidyDownloads.onPodDismissed((podData) => {
      debugLog("Received pod dismissal:", podData);
      addPodToPile(podData);
    });

    // Download button hover events
    if (state.downloadButton) {
      state.downloadButton.addEventListener('mouseenter', handleDownloadButtonHover);
      state.downloadButton.addEventListener('mouseleave', handleDownloadButtonLeave);
    }

    // Dynamic sizer hover events (keep container open when cursor is inside)
    if (state.dynamicSizer) {
      state.dynamicSizer.addEventListener('mouseenter', handleDynamicSizerHover);
      state.dynamicSizer.addEventListener('mouseleave', handleDynamicSizerLeave);
      debugLog("Added hover listeners to dynamic sizer");
    }

    // Pile container hover events
    state.pileContainer.addEventListener('mouseenter', handlePileHover);
    state.pileContainer.addEventListener('mouseleave', handlePileLeave);

    // Alt key listeners for always-show mode
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);

    // Preference change listener
    setupPreferenceListener();

    // Window resize handler
    window.addEventListener('resize', debounce(recalculateLayout, 250));

    // Listen for actual download removals from Firefox list (via main script)
    if (window.zenTidyDownloads && typeof window.zenTidyDownloads.onActualDownloadRemoved === 'function') {
      window.zenTidyDownloads.onActualDownloadRemoved((removedKey) => {
        debugLog(`[PileSync] Received actual download removal notification for key: ${removedKey}`);
        if (state.dismissedPods.has(removedKey)) {
          removePodFromPile(removedKey);
          debugLog(`[PileSync] Removed pod ${removedKey} from pile as it was cleared from Firefox list.`);
        }
      });
      debugLog("[PileSync] Registered listener for actual download removals.");
    } else {
      debugLog("[PileSync] Could not register listener for actual download removals - API not found on main script.");
    }

    // Sticky pod hover: expand pile when user hovers over a sticky pod
    document.addEventListener('request-pile-expand', () => {
      if (state.dismissedPods.size > 0) {
        showPile();
        showPileBackground();
        schedulePileLayoutRepair("request-pile-expand", 60);
      }
    });

    // Context menu click-outside handler
    document.addEventListener('click', (e) => {
      if (window.zenPileContextMenu &&
        !window.zenPileContextMenu.contextMenu.contains(e.target)) {
        hideContextMenu();
      }
    });

    // Periodic cheap repair: mask/sizer can desync after sticky transitions or toolbar reflow
    if (state.pileLayoutRepairIntervalId) {
      clearInterval(state.pileLayoutRepairIntervalId);
    }
    state.pileLayoutRepairIntervalId = setInterval(() => {
      if (state.dismissedPods.size > 0) {
        schedulePileLayoutRepair("interval", 0);
      }
    }, 90000);

    debugLog("Event listeners setup complete");
  }

  // Load any existing dismissed pods from main script
  function loadExistingDismissedPods() {
    const existingPods = window.zenTidyDownloads.dismissedPods.getAll();
    existingPods.forEach((podData, key) => {
      addPodToPile(podData, false); // Don't animate existing pods
    });
    debugLog(`Loaded ${existingPods.size} existing dismissed pods`);

    // Restore dismissed pods from SessionStore
    restoreDismissedPodsFromSession();

    // If always-show mode is enabled and we have pods, show the pile
    if (getAlwaysShowPile() && existingPods.size > 0) {
      setTimeout(() => {
        if (shouldPileBeVisible()) {
          showPile();
          debugLog("[AlwaysShow] Showing pile on startup - always-show mode enabled");
        }
      }, 100); // Small delay to ensure DOM is ready
    }
  }

  // Add a pod to the pile
  function addPodToPile(podData, animate = true) {
    if (!podData || !podData.key) {
      debugLog("Invalid pod data for pile addition");
      return;
    }

    // Limit to 4 most recent pods
    if (state.dismissedPods.size >= 4) {
      const oldestKey = Array.from(state.dismissedPods.keys())[0];
      removePodFromPile(oldestKey);
    }

    // Store pod data
    state.dismissedPods.set(podData.key, podData);

    // Save to SessionStore for persistence
    saveDismissedPodToSession(podData);

    // Update the list of pod keys in SessionStore
    updatePodKeysInSession();

    // Create DOM element
    const podElement = createPodElement(podData);
    state.podElements.set(podData.key, podElement);
    state.pileContainer.appendChild(podElement);

    // Generate position for single column layout
    generateGridPosition(podData.key);

    // Apply position immediately (no messy pile mode)
    applyGridPosition(podData.key, animate ? 0 : 0);

    // Update pile visibility
    updatePileVisibility();

    // Update downloads button visibility
    updateDownloadsButtonVisibility();

    // Show the pile immediately when a pod is added
    if (shouldPileBeVisible()) {
      showPile();
      // Update text colors after showing pile
      setTimeout(() => {
        updatePodTextColors();
      }, 50);
    }

    schedulePileLayoutRepair("add-pod", 120);

    debugLog(`Added pod to pile: ${podData.filename}`);
  }

  // Create a DOM element for a dismissed pod
  function createPodElement(podData) {
    // Create row container that spans full width
    const row = document.createElement("div");
    row.className = "dismissed-pod-row";
    row.dataset.podKey = podData.key;
    row.title = `${podData.filename}\nClick: Open file\nMiddle-click: Show in file explorer\nRight-click: Context menu`;

    row.style.cssText = `
      position: absolute;
      width: 100%;
      height: 48px;
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
      padding: 0 8px;
      box-sizing: border-box;
      cursor: pointer;
      transition: opacity 0.1s ease, background-color 0.1s ease, transform 0.1s ease;
      will-change: transform, opacity;
      left: 0;
      right: 0;
      border-radius: 6px;
    `;

    // Add hover background color
    row.addEventListener('mouseenter', () => {
      row.style.backgroundColor = 'rgba(255, 255, 255, 0.08)';
    });

    row.addEventListener('mouseleave', () => {
      row.style.backgroundColor = 'transparent';
    });

    // Create pod thumbnail (left side)
    const pod = document.createElement("div");
    pod.className = "dismissed-pod";
    pod.style.cssText = `
      width: 36px;
      height: 36px;
      min-width: 36px;
      border-radius: 6px;
      overflow: hidden;
      flex-shrink: 0;
    `;

    // Create preview content
    const preview = document.createElement("div");
    preview.className = "dismissed-pod-preview";
    preview.style.cssText = `
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: transparent; /* Changed from #2a2a2a to transparent */
      color: white;
      font-size: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;

    const isImageFile = (filename, contentType) =>
      !!(contentType && contentType.startsWith("image/")) ||
      filenameEndsWithExtensionFromSet(filename, IMAGE_EXTENSIONS);

    const isTextFile = (filename, contentType) =>
      !!(contentType && contentType.startsWith("text/")) ||
      filenameEndsWithExtensionFromSet(filename, TEXT_EXTENSIONS);

    const isSystemIconFile = (filename, contentType) => {
      if (contentType && (contentType.startsWith("video/") || contentType.startsWith("audio/") || contentType.includes("pdf"))) {
        return true;
      }
      return filenameEndsWithExtensionFromSet(filename, SYSTEM_ICON_EXTENSIONS);
    };

    // Set preview content
    // Priority: Image -> Text -> System Icon -> Generic Icon
    
    const renderPreview = async () => {
        // 1. Image (always show when available - not gated by pref)
        if (podData.previewData && podData.previewData.type === 'image' && podData.previewData.src) {
             const img = document.createElement("img");
            img.src = podData.previewData.src;
            img.style.cssText = `
              width: 100%;
              height: 100%;
              object-fit: cover;
            `;
            img.onload = () => {
              // Image loaded
            };
            img.onerror = (e) => {
              // Fallback
              const icon = getFileIcon(podData.contentType);
              renderIcon(icon);
            };
            preview.appendChild(img);
            return;
        }
        
        // 2. Text File (if path available - disabled by default via pref)
        if (podData.targetPath && isTextFile(podData.filename, podData.contentType)) {
             if (zenStuffFilePreviewEnabled) {
                  const textContent = await readTextFilePreview(podData.targetPath);
                  if (textContent) {
                      preview.innerHTML = "";
                      const textDiv = document.createElement("div");
                      textDiv.style.cssText = `
                          width: 100%;
                          height: 100%;
                          padding: 4px;
                          box-sizing: border-box;
                          font-family: monospace;
                          font-size: 5px; 
                          line-height: 1.1;
                          overflow: hidden;
                          white-space: pre-wrap;
                          color: rgba(255,255,255,0.8);
                          background: rgba(0,0,0,0.2);
                          text-align: left;
                          word-break: break-all;
                      `;
                      textDiv.textContent = textContent;
                      preview.appendChild(textDiv);
                      return;
                  }
             }
             // No preview - use system icon for text files
             const fileUrl = "file:///" + podData.targetPath.replace(/\\/g, "/");
             const iconUrl = `moz-icon://${fileUrl}?size=32`;
             const img = document.createElement("img");
             img.src = iconUrl;
             img.style.cssText = `width: 100%; height: 100%; object-fit: cover;`;
             img.onerror = () => {
                 const icon = getFileIcon(podData.contentType);
                 renderIcon(icon);
             };
             preview.innerHTML = "";
             preview.appendChild(img);
             return;
        }

        // 3. System Icon (for .exe, video, pdf, etc.)
        if (podData.targetPath && isSystemIconFile(podData.filename, podData.contentType)) {
            const fileUrl = "file:///" + podData.targetPath.replace(/\\/g, "/");
            const iconUrl = `moz-icon://${fileUrl}?size=32`;
            
            const img = document.createElement("img");
            img.src = iconUrl;
            img.style.cssText = `
              width: 100%;
              height: 100%;
              object-fit: cover; /* Make it fill the container like images */
            `;
            
            // If system icon fails, fallback to generic
            img.onerror = () => {
                const icon = getFileIcon(podData.contentType);
                renderIcon(icon);
            };
            
            preview.innerHTML = "";
            preview.appendChild(img);
            return;
        }

        // 4. Fallback to Generic Icon
        const icon = getFileIcon(podData.contentType);
        renderIcon(icon);
    };
    
    const renderIcon = (iconChar) => {
        const iconSpan = document.createElement("span");
        iconSpan.style.fontSize = "24px";
        iconSpan.textContent = iconChar;
        preview.innerHTML = "";
        preview.appendChild(iconSpan);
    };

    renderPreview();

    pod.appendChild(preview);
    row.appendChild(pod);

    // Create text container (right side)
    const textContainer = document.createElement("div");
    textContainer.className = "dismissed-pod-text";
    textContainer.style.cssText = `
      display: flex;
      flex-direction: column;
      justify-content: center;
      flex: 1;
      min-width: 0;
      overflow: hidden;
      height: 100%;
    `;

    // Create filename element (editable inline)
    const filename = document.createElement("div");
    filename.className = "dismissed-pod-filename";
    
    // Ensure filename matches the actual file on disk if possible, handling OS auto-renaming (e.g., "file(1).jpg")
    let displayFilename = podData.filename || "Untitled";
    if (podData.targetPath) {
      try {
        // Extract the filename from the full path to ensure it matches the actual file on disk
        // This catches cases where the OS renamed the file (e.g. adding (1)) but podData.filename was stale
        const pathSeparator = podData.targetPath.includes('\\') ? '\\' : '/';
        const actualFilename = podData.targetPath.split(pathSeparator).pop();
        if (actualFilename && actualFilename !== displayFilename) {
            displayFilename = actualFilename;
        }
      } catch (e) {
        // Fallback to existing filename if parsing fails
      }
    }
    
    filename.textContent = displayFilename;
    filename.style.cssText = `
      font-size: 12px;
      font-weight: 500;
      color: var(--zen-text-color, #e0e0e0);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 2px;
      cursor: pointer;
      user-select: text;
    `;
    
    // Store reference to filename element for inline editing via context menu
    // Inline editing is only triggered from context menu, not double-click

    // Create file size element
    const fileSize = document.createElement("div");
    fileSize.className = "dismissed-pod-filesize";
    const sizeBytes = podData.fileSize || 0;
    fileSize.textContent = formatBytes(sizeBytes);
    fileSize.style.cssText = `
      font-size: 10px;
      color: var(--zen-text-color-deemphasized, #a0a0a0);
      white-space: nowrap;
    `;

    textContainer.appendChild(filename);
    textContainer.appendChild(fileSize);
    row.appendChild(textContainer);

    // Add click handler for opening in file explorer
    row.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      debugLog(`Attempting to open file: ${podData.key}`);
      openPodFile(podData);
    });

    // Add middle-click handler for showing in file explorer
    row.addEventListener('mousedown', (e) => {
      if (e.button === 1) { // Middle mouse button
        e.preventDefault();
        e.stopPropagation();
        debugLog(`Attempting to show file in explorer: ${podData.key}`);
        showPodFileInExplorer(podData);
      }
    });

    // Add right-click handler - use native menupopup
    row.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      state.pileContextMenuActive = true;
      ensurePodContextMenu();
      podContextMenuPodData = podData;
      // Open at mouse position
      if (typeof podContextMenu.openPopupAtScreen === 'function') {
        podContextMenu.openPopupAtScreen(e.screenX, e.screenY, true);
      } else {
        // fallback: open at pod
        podContextMenu.openPopup(row, 'after_start', 0, 0, true, false, e);
      }
    });

    // Add drag-and-drop support for dragging to web pages
    row.setAttribute('draggable', 'true');
    row.addEventListener('dragstart', async (e) => {
      // Only allow drag if we have a file path
      if (!podData.targetPath) {
        e.preventDefault();
        return;
      }
      
      // Ensure image (if present) is loaded before allowing drag
      const img = pod.querySelector('img');
      if (img && !img.complete) {
        // Optionally, prevent drag or use a fallback icon
        e.preventDefault();
        debugLog('[DragDrop] Image not loaded, preventing drag for:', podData.filename);
        return;
      }
      
      // Try to get the file instance
      try {
        const file = await FileSystem.createFileInstance(podData.targetPath);
        if (!file.exists()) {
          e.preventDefault();
          return;
        }
        
        // Set the native file flavor for Firefox - use try/catch to handle potential DOMException
        try {
          if (e.dataTransfer && typeof e.dataTransfer.mozSetDataAt === 'function') {
            e.dataTransfer.mozSetDataAt('application/x-moz-file', file, 0);
          }
        } catch (mozError) {
          debugLog('[DragDrop] mozSetDataAt failed, continuing with other formats:', mozError);
          // Continue with other data formats even if mozSetDataAt fails
        }
        
        // Set URI flavors for web pages
        const fileUrl = file && file.path ?
          (file.path.startsWith('\\') ? 'file:' + file.path.replace(/\\/g, '/') : 'file:///' + file.path.replace(/\\/g, '/'))
          : '';
        if (fileUrl) {
          e.dataTransfer.setData('text/uri-list', fileUrl);
          e.dataTransfer.setData('text/plain', fileUrl);
        }
        
        // Optionally, set a download URL for HTML5 drop targets
        if (podData.sourceUrl) {
          e.dataTransfer.setData('DownloadURL', `${podData.contentType || 'application/octet-stream'}:${podData.filename}:${podData.sourceUrl}`);
        }
        
        // Force reflow to ensure the pod is painted
        pod.offsetWidth;
        e.dataTransfer.setDragImage(pod, 22, 22);
      } catch (err) {
        debugLog('[DragDrop] Error during dragstart:', err);
        e.preventDefault();
      }
    });

    return row;
  }

  // Get file icon based on content type
  function getFileIcon(contentType) {
    if (!contentType) return "📄";

    if (contentType.includes("image/")) return "🖼️";
    if (contentType.includes("video/")) return "🎬";
    if (contentType.includes("audio/")) return "🎵";
    if (contentType.includes("text/")) return "📝";
    if (contentType.includes("application/pdf")) return "📕";
    if (contentType.includes("application/zip") || contentType.includes("application/x-rar")) return "🗜️";
    if (contentType.includes("application/")) return "📦";

    return "📄";
  }

  // Generate random pile position for a pod
  function generatePilePosition(podKey) {
    const angle = (Math.random() - 0.5) * CONFIG.pileRotationRange * 2;
    const offsetX = (Math.random() - 0.5) * CONFIG.pileOffsetRange * 2;
    const offsetY = (Math.random() - 0.5) * CONFIG.pileOffsetRange * 2;

    // Newer pods should have higher z-index to appear on top
    // Get the order of this pod in the dismissedPods map (newer = higher index)
    const pods = Array.from(state.dismissedPods.keys());
    const podIndex = pods.indexOf(podKey);
    const zIndex = podIndex + 1; // Start from 1, newer pods get higher z-index

    state.pilePositions.set(podKey, {
      x: offsetX,
      y: offsetY,
      rotation: angle,
      zIndex: zIndex
    });

    debugLog(`Generated pile position for ${podKey}:`, {
      index: podIndex,
      zIndex,
      angle,
      offsetX,
      offsetY
    });
  }

  // Generate position for a pod (single column layout, bottom-up, 4 most recent)
  function generateGridPosition(podKey) {
    // Get the 4 most recent pods (newest last in the map)
    const allPods = Array.from(state.dismissedPods.keys());
    const recentPods = allPods.slice(-4); // Get last 4 pods (most recent)
    const index = recentPods.indexOf(podKey);

    if (index === -1) {
      // This pod is not in the 4 most recent, don't position it
      return;
    }

    // Single column layout - newest at bottom (row 0), older pods stack upward.
    // Invert the index: newest (last in recentPods array) gets row 0 (bottom),
    // oldest (first in recentPods array) gets the highest row.
    const x = 0;
    const rowIndex = (recentPods.length - 1) - index; // 0 = bottom (newest)

    state.gridPositions.set(podKey, { x, y: 0, row: rowIndex, col: 0 });

    debugLog(`Single column position (bottom-up) for ${podKey}:`, {
      index,
      rowIndex,
      x,
      totalRecent: recentPods.length
    });
  }

  // Apply pile position to a pod
  function applyPilePosition(podKey, animate = true) {
    const podElement = state.podElements.get(podKey);
    const position = state.pilePositions.get(podKey);
    if (!podElement || !position) return;

    const transform = `translate3d(${position.x}px, ${position.y}px, 0) rotate(${position.rotation}deg)`;

    if (!animate) {
      podElement.style.transition = 'none';
    }

    podElement.style.transform = transform;
    podElement.style.zIndex = position.zIndex;

    if (!animate) {
      // Re-enable transitions after position is set
      requestAnimationFrame(() => {
        podElement.style.transition = `transform ${CONFIG.animationDuration}ms cubic-bezier(0.4, 0, 0.2, 1)`;
      });
    }
  }

  // Apply position to a pod (simple single column, no rotation)
  // preserveTransition: when true, don't overwrite transition (caller set transition-delay for stagger)
  function applyGridPosition(podKey, delay = 0, shouldAnimate = false, preserveTransition = false) {
    const podElement = state.podElements.get(podKey);
    const position = state.gridPositions.get(podKey);
    if (!podElement || !position) {
      // If no position, hide the pod (it's not in the 4 most recent)
      if (podElement) {
        podElement.style.display = 'none';
      }
      return;
    }

    const update = () => {
      // Set transition if animation is needed (skip when caller uses transition-delay for stagger)
      if (shouldAnimate && !preserveTransition) {
        podElement.style.transition = `opacity ${CONFIG.animationDuration}ms ease, transform ${CONFIG.animationDuration}ms ease`;
      }
      // Use bottom positioning for bottom-up layout
      const rowHeight = 48;
      const rowSpacing = 6;
      const baseBottomOffset = 8; // Small base offset for first row
      const bottomOffset = baseBottomOffset + (position.row * (rowHeight + rowSpacing));
      
      podElement.style.bottom = '0px';
      podElement.style.left = '0';
      podElement.style.right = '0';
      podElement.style.top = 'auto';
      // Use translateY to move up (negative value)
      podElement.style.transform = `translate3d(0, -${bottomOffset}px, 0)`;
      podElement.style.display = 'flex'; // Ensure flex layout is maintained
      podElement.style.zIndex = '1';
      podElement.style.opacity = '1';
    };

    if (preserveTransition) {
      // Caller batches updates in single frame; apply immediately
      update();
    } else if (delay > 0) {
      setTimeout(() => requestAnimationFrame(update), delay);
    } else {
      requestAnimationFrame(update);
    }
  }

  // Remove a pod from the pile
  function removePodFromPile(podKey) {
    const podElement = state.podElements.get(podKey);
    const wasVisible = state.dynamicSizer && state.dynamicSizer.style.height !== '0px';
    
    if (podElement) {
      // Set lower z-index and disable pointer events to prevent overlap during animation
      podElement.style.zIndex = '0';
      podElement.style.pointerEvents = 'none';
      
      // Animate out using transform and opacity only
      requestAnimationFrame(() => {
        podElement.style.transition = `opacity ${CONFIG.animationDuration}ms ease, transform ${CONFIG.animationDuration}ms ease`;
        
        // Preserve current position but scale down
        const position = state.gridPositions.get(podKey);
        if (position) {
             const rowHeight = 48;
             const rowSpacing = 6;
             const baseBottomOffset = 8;
             const bottomOffset = baseBottomOffset + (position.row * (rowHeight + rowSpacing));
             podElement.style.transform = `translate3d(0, -${bottomOffset}px, 0) scale(0.8)`;
        } else {
             podElement.style.transform = 'scale(0.8)';
        }
        
        podElement.style.opacity = '0';
      });

      setTimeout(() => {
        if (podElement.parentNode) {
          podElement.parentNode.removeChild(podElement);
        }
      }, CONFIG.animationDuration);
    }

    state.dismissedPods.delete(podKey);
    state.podElements.delete(podKey);
    state.pilePositions.delete(podKey);
    state.gridPositions.delete(podKey);

    // Remove from SessionStore
    removeDismissedPodFromSession(podKey);

    // Update the list of pod keys in SessionStore
    updatePodKeysInSession();

    // Clear any pending hide timeout to prevent pile from hiding too quickly after removal
    if (state.hoverTimeout) {
      clearTimeout(state.hoverTimeout);
      state.hoverTimeout = null;
    }

    // Set flag to prevent pile from hiding immediately after removal
    state.recentlyRemoved = true;

    // Recalculate grid positions for remaining pods
    state.dismissedPods.forEach((_, key) => generateGridPosition(key));

    // If pile was visible, animate remaining pods to new positions
    // Wait for removal animation to fully complete before repositioning to avoid overlap
    if (wasVisible && state.dismissedPods.size > 0) {
      // Ensure pile stays visible during and after removal animation
      showPile();
      
      const removalDelay = CONFIG.animationDuration + 50;
      setTimeout(() => {
        updatePileVisibility(true); // Pass true to indicate we should animate
        // Update downloads button visibility
        updateDownloadsButtonVisibility();
        
        // Clear the flag after repositioning animation completes + grace period
        setTimeout(() => {
          state.recentlyRemoved = false;
          debugLog("[RemovePod] Cleared recentlyRemoved flag - pile can now hide normally");
          
          // After clearing the flag, check if we should hide the pile
          // (if user is not hovering and not in always-show mode)
          if (!getAlwaysShowPile() && !shouldDisableHover()) {
            const isHoveringDownloadArea = state.downloadButton?.matches(':hover');
            const isHoveringPile = isHoveringPileArea();

            if (!isHoveringDownloadArea && !isHoveringPile) {
              // Start the hide timeout
              clearTimeout(state.hoverTimeout);
              state.hoverTimeout = setTimeout(() => {
                hidePile();
              }, CONFIG.hoverDebounceMs);
            }
          }
        }, removalDelay); // Wait for repositioning animation
      }, removalDelay); // Wait for full fade-out
    } else {
      // updatePileVisibility will handle sizer height if needed
      updatePileVisibility(); // This will now call showPile/hidePile which adjust sizer
      // Update downloads button visibility
      updateDownloadsButtonVisibility();
      // Clear the flag since pile is now empty
      state.recentlyRemoved = false;
    }
  }

  // Update pile visibility based on pod count
  function updatePileVisibility(shouldAnimate = false) {
    if (state.dismissedPods.size === 0) {
      // If pile becomes empty, hide it (will set sizer height to 0)
      if (state.dynamicSizer && state.dynamicSizer.style.height !== '0px') {
        hidePile();
      }
    } else {
      // Show only the 4 most recent pods
      const allPods = Array.from(state.dismissedPods.keys());
      const recentPods = allPods.slice(-4); // Get last 4 pods (most recent)

      // Regenerate positions for all pods
      allPods.forEach(podKey => {
        generateGridPosition(podKey);
        // If animating (e.g., after removal), animate remaining pods to new positions
        applyGridPosition(podKey, 0, shouldAnimate);
      });

      // If pile is currently visible, recalculate height dynamically
      if (state.dynamicSizer && state.dynamicSizer.style.height !== '0px') {
        updatePileHeight();
      }
    }
  }

  // Update pile height dynamically based on current pod count (max 4)
  function updatePileHeight() {
    if (!state.dynamicSizer || state.dismissedPods.size === 0) return;

    const rowHeight = 48; // Height of each row (pod + text)
    const rowSpacing = 6; // Spacing between rows

    // Always show max 4 pods
    const podsToShow = Math.min(state.dismissedPods.size, 4);

    // Calculate height: (rows * row height) + spacing between rows + space below first pod
    // The baseBottomOffset in positioning creates the space, so we add it to height to accommodate it
    const baseBottomOffset = 8; // Space under first pod row (matches applyGridPosition)
    const totalRowHeight = (podsToShow * rowHeight) + ((podsToShow - 1) * rowSpacing);
    const gridHeight = totalRowHeight + baseBottomOffset;

    debugLog("Updating pile height dynamically", {
      totalPods: state.dismissedPods.size,
      podsToShow,
      oldHeight: state.dynamicSizer.style.height,
      newHeight: `${gridHeight}px`
    });

    state.dynamicSizer.style.height = `${gridHeight}px`;

    // Update the mask height variable on document root for #zen-tabs-wrapper mask
    // Subtract media toolbar height when visible so the mask accounts for its space
    const mediaToolbar = document.getElementById('zen-media-controls-toolbar');
    const mediaToolbarHeight = mediaToolbar?.getBoundingClientRect().height ?? 0;
    const pileMaskHeight = Math.max(0, gridHeight - (mediaToolbarHeight > 0 ? mediaToolbarHeight : 0));
    document.documentElement.style.setProperty('--zen-pile-height', `${pileMaskHeight}px`);
  }

  // Update pile position relative to download button
  function updatePilePosition() {
    // This function is largely obsolete as the pile is now in-flow within dynamicSizer.
    // Width will be handled by updatePileContainerWidth.
    // Height will be handled by showPile/hidePile.
    debugLog("updatePilePosition called, but largely obsolete now.");
    // If dynamicSizer exists and we need to ensure its width is up-to-date:
    if (typeof updatePileContainerWidth === 'function') {
      // updatePileContainerWidth(); // Call this if needed, but it's called on showPile
    }
  }

  // Download button hover handler
  function handleDownloadButtonHover() {
    debugLog("[DownloadHover] handleDownloadButtonHover called", {
      dismissedPodsSize: state.dismissedPods.size,
      shouldDisableHover: shouldDisableHover(),
      alwaysShowMode: getAlwaysShowPile()
    });

    if (state.dismissedPods.size === 0) return;

    // In always-show mode, don't handle hover events
    if (getAlwaysShowPile()) {
      debugLog("[DownloadHover] Always-show mode enabled - ignoring hover");
      return;
    }

    // Check if main download script has active pods and disable hover if so
    if (shouldDisableHover()) {
      debugLog("[HoverDisabled] Pile hover disabled - main download script has active pods");
      return;
    }

    clearTimeout(state.hoverTimeout);
    state.hoverTimeout = setTimeout(() => {
      debugLog("[DownloadHover] Timeout triggered - calling showPile()");
      showPile();
      schedulePileLayoutRepair("download-hover", 50);
    }, CONFIG.hoverDebounceMs);
  }

  // Download button leave handler
  function handleDownloadButtonLeave() {
    debugLog("[DownloadHover] handleDownloadButtonLeave called");

    // In always-show mode, don't handle hover events
    if (getAlwaysShowPile()) {
      debugLog("[DownloadHover] Always-show mode enabled - ignoring leave");
      return;
    }

    if (shouldDisableHover()) {
      return; // Don't process leave events if hover is disabled
    }

    if (isContextMenuVisible()) {
      debugLog("[DownloadHover] Context menu visible - deferring pile close");
      state.pendingPileClose = true;
      return;
    }

    clearTimeout(state.hoverTimeout);
    state.hoverTimeout = setTimeout(() => {
      const isHoveringDownloadArea = state.downloadButton?.matches(':hover');

      debugLog("[DownloadHover] Leave timeout - checking hover states", {
        isHoveringDownloadArea,
        pileContainerHover: state.pileContainer?.matches(':hover'),
        dynamicSizerHover: state.dynamicSizer?.matches(':hover')
      });

      // Only hide if cursor is not over download button AND not over pile/bridge
      if (!isHoveringDownloadArea && !isHoveringPileArea()) {
        if (isContextMenuVisible()) {
          debugLog("[DownloadHover] Context menu visible at timeout - deferring pile close");
          state.pendingPileClose = true;
        } else {
          debugLog("[DownloadHover] Calling hidePile()");
          hidePile();
        }
      }
    }, CONFIG.hoverDebounceMs);
  }

  // Dynamic sizer hover handler  
  function handleDynamicSizerHover() {
    debugLog("[SizerHover] handleDynamicSizerHover called");

    if (getAlwaysShowPile()) return;
    
    clearTimeout(state.hoverTimeout);
    
    // Keep pile visible while hovering over sizer and maintain mask
    if (state.dismissedPods.size > 0) {
      showPile();
      showPileBackground();
      schedulePileLayoutRepair("sizer-hover", 40);
      debugLog("[SizerHover] Maintaining pile visibility and mask during sizer hover");
    }
  }

  // Dynamic sizer leave handler
  function handleDynamicSizerLeave(event) {
    debugLog("[SizerHover] handleDynamicSizerLeave called");

    clearTimeout(state.hoverTimeout);

    // If moving into pile content (e.g. from sizer edge to a row), don't schedule hide
    if (event?.relatedTarget && state.pileContainer?.contains(event.relatedTarget)) {
      debugLog("[SizerHover] Moving into pile - not scheduling hide");
      return;
    }

    // Don't do anything if context menu is visible
    if (isContextMenuVisible()) {
      debugLog("[SizerHover] Context menu visible - deferring pile close");
      state.pendingPileClose = true;
      return;
    }

    // In always-show mode, don't handle pile visibility
    if (getAlwaysShowPile()) {
      debugLog("[SizerHover] Always-show mode - only handling grid transition");
      return;
    }

    // Normal mode: handle pile hiding
    state.hoverTimeout = setTimeout(() => {
      const isHoveringDownloadArea = state.downloadButton?.matches(':hover');
      const isHoveringPile = isHoveringPileArea();

      debugLog("[SizerHover] Leave timeout - checking hover states", {
        isHoveringDownloadArea,
        pileAreaHover: isHoveringPile,
        contextMenuVisible: isContextMenuVisible()
      });

      // Only hide if not hovering download button AND not hovering pile/bridge AND context menu not visible
      if (!isHoveringDownloadArea && !isHoveringPile) {
        if (isContextMenuVisible()) {
          debugLog("[SizerHover] Context menu visible at timeout - deferring pile close");
          state.pendingPileClose = true;
        } else {
          debugLog("[SizerHover] Calling hidePile()");
          hidePile();
        }
      }
    }, CONFIG.hoverDebounceMs);
  }

  // Pile hover handler (simplified - no mode transitions)
  function handlePileHover() {
    debugLog("[PileHover] handlePileHover called");

    clearTimeout(state.hoverTimeout);
    
    // Ensure pile background and mask remain active during hover
    showPileBackground();
    
    // If pile is visible, ensure it stays visible during hover
    if (state.dismissedPods.size > 0 && state.dynamicSizer && state.dynamicSizer.style.height !== '0px') {
      schedulePileLayoutRepair("pile-hover", 40);
      debugLog("[PileHover] Maintaining pile visibility and mask during hover");
    }
  }

  // Pile leave handler (simplified)
  function handlePileLeave(event) {
    debugLog("[PileHover] handlePileLeave called");

    clearTimeout(state.hoverTimeout);

    // If moving within pile area (e.g. between rows), don't schedule hide
    if (event?.relatedTarget && state.dynamicSizer?.contains(event.relatedTarget)) {
      debugLog("[PileHover] Moving within pile area - not scheduling hide");
      return;
    }

    // Don't do anything if context menu is visible
    if (isContextMenuVisible()) {
      debugLog("[PileHover] Context menu visible - deferring pile close");
      state.pendingPileClose = true;
      return;
    }

    // In always-show mode, don't hide the pile
    if (getAlwaysShowPile()) {
      return;
    }

    // Normal mode: handle pile hiding
    state.hoverTimeout = setTimeout(() => {
      const isHoveringDownloadArea = state.downloadButton?.matches(':hover');

      if (!isHoveringDownloadArea && !isHoveringPileArea()) {
        if (isContextMenuVisible()) {
          state.pendingPileClose = true;
        } else {
          debugLog("[PileHover] Calling hidePile()");
          hidePile();
        }
      }
    }, CONFIG.hoverDebounceMs);
  }

  // Show the pile
  function showPile() {
    debugLog("[ShowPile] showPile called", {
      dismissedPodsSize: state.dismissedPods.size,
      currentHeight: state.dynamicSizer?.style.height,
      // Removed isGridMode
      alwaysShowMode: getAlwaysShowPile()
    });

    if (state.dismissedPods.size === 0 || !state.dynamicSizer) return;

    // Check if pile is currently visible to prevent double animation
    const wasVisible = state.dynamicSizer.style.height !== '0px';

    // Check compact mode state - hide pile if sidebar is collapsed (similar to media controls)
    const isCompactMode = document.documentElement.getAttribute('zen-compact-mode') === 'true';
    const isSidebarExpanded = document.documentElement.getAttribute('zen-sidebar-expanded') === 'true';

    if (isCompactMode && !isSidebarExpanded) {
      // In compact mode with collapsed sidebar, hide the pile (like media controls)
      debugLog("[ShowPile] Compact mode with collapsed sidebar - hiding pile");
      state.dynamicSizer.style.display = 'none';
      return;
    }

    // Show the pile
    state.dynamicSizer.style.display = 'flex';

    // Ensure width is set before calculating positions
    if (typeof updatePileContainerWidth === 'function') {
      updatePileContainerWidth();
    }

    // Parent container spans full toolbar width
    state.dynamicSizer.style.left = '0px';
    state.dynamicSizer.style.right = '0px';
    // Remove width when using left/right - it's automatically calculated

    debugLog("Positioned pile for full-width container", {
      position: state.dynamicSizer.style.position,
      left: state.dynamicSizer.style.left,
      right: state.dynamicSizer.style.right
    });

    // Set pointer-events based on mode and state
    updatePointerEvents();

    state.dynamicSizer.style.paddingBottom = '0px'; // No padding - space comes from baseBottomOffset
    state.dynamicSizer.style.paddingLeft = `0px`; // No left padding for full-width rows

    // Calculate dynamic height for 4 most recent pods
    const totalPods = state.dismissedPods.size;
    const podsToShow = Math.min(totalPods, 4); // Always max 4 pods

    const rowHeight = 48; // Height of each row (pod + text)
    const rowSpacing = 6; // Spacing between rows

    // Calculate height: (rows * row height) + spacing between rows + space below first pod
    // The baseBottomOffset in positioning creates the space, so we add it to height to accommodate it
    const baseBottomOffset = 8; // Space under first pod row (matches applyGridPosition)
    const totalRowHeight = (podsToShow * rowHeight) + ((podsToShow - 1) * rowSpacing);
    const gridHeight = totalRowHeight + baseBottomOffset;

    debugLog("Dynamic height calculation (4 most recent)", {
      totalPods,
      podsToShow,
      calculatedHeight: gridHeight
    });

    state.dynamicSizer.style.height = `${gridHeight}px`;

    // Show hover bridge to cover gap between download button and pile
    if (state.hoverBridge) {
      state.hoverBridge.style.display = 'block';
    }

    // Update mask height variable for #zen-tabs-wrapper mask
    // Subtract media toolbar height when visible so the mask accounts for its space
    const mediaControlsToolbar = document.getElementById('zen-media-controls-toolbar');
    const mediaToolbarHeight = mediaControlsToolbar?.getBoundingClientRect().height ?? 0;
    const pileMaskHeight = Math.max(0, gridHeight - (mediaToolbarHeight > 0 ? mediaToolbarHeight : 0));
    document.documentElement.style.setProperty('--zen-pile-height', `${pileMaskHeight}px`);

    // Apply mask on media controls toolbar for seamless blend when pile expands
    if (mediaControlsToolbar) {
      mediaControlsToolbar.classList.add('zen-pile-expanded');
    }

    // Set background to ensure backdrop-filter is properly rendered
    showPileBackground();

    // Mask is applied in hover handlers, not here

    // Hide workspace-arrowscrollbox::after when pile is showing
    hideWorkspaceScrollboxAfter();

    // Update positions for all pods (show only 4 most recent)
    const recentPods = Array.from(state.dismissedPods.keys()).slice(-4);

    if (!wasVisible) {
      // Reset pods to hidden state
      recentPods.forEach(podKey => {
        const el = state.podElements.get(podKey);
        if (el) {
          el.style.transition = 'none';
          el.style.opacity = '0';
          el.style.transform = 'translateY(20px)';
        }
      });

      // Force reflow so reset state is applied before we set transitions
      if (state.dynamicSizer) state.dynamicSizer.offsetHeight;

      // Use CSS transition-delay for stagger (all transitions start same frame, predictable order)
      // Order: oldest (index 0) first, newest (index 3) last
      recentPods.forEach((podKey, index) => {
        const el = state.podElements.get(podKey);
        if (el) {
          const delayMs = index * CONFIG.gridAnimationDelay;
          el.style.transition = `opacity ${CONFIG.animationDuration}ms ease ${delayMs}ms, transform ${CONFIG.animationDuration}ms ease ${delayMs}ms`;
        }
      });

      // Batch all position updates in single frame for consistent animation start
      recentPods.forEach(podKey => generateGridPosition(podKey));
      requestAnimationFrame(() => {
        recentPods.forEach(podKey => applyGridPosition(podKey, 0, false, true));
      });
    } else {
      // Already visible: update positions without stagger
      recentPods.forEach((podKey) => {
        generateGridPosition(podKey);
        applyGridPosition(podKey, 0);
      });
    }

    // Ensure hover events are properly set up for the current mode
    // This is important after the pile was hidden and is being shown again
    setTimeout(() => {
      setupPileBackgroundHoverEvents();
      debugLog("[ShowPile] Hover events re-setup after pile shown");
    }, 50); // Small delay to ensure DOM is updated

    // Notify tidy-downloads that the pile is showing so it can remove sticky pods from the pods row
    document.dispatchEvent(new CustomEvent('pile-shown', { bubbles: true }));

    debugLog("Showing pile with single column layout", {
      totalPods,
      podsToShow,
      dynamicHeight: gridHeight
    });

    schedulePileLayoutRepair("show-pile", 30);
  }

  // Hide the pile
  function hidePile() {
    debugLog("[HidePile] hidePile called", {
      currentHeight: state.dynamicSizer?.style.height,
      isEditing: state.isEditing,
      recentlyRemoved: state.recentlyRemoved
    });

    // Don't hide pile if user is editing a filename
    if (state.isEditing) {
      debugLog("[HidePile] Pile kept visible - editing in progress");
      return;
    }

    // Don't hide pile if a pod was recently removed (give user time to see the result)
    if (state.recentlyRemoved) {
      debugLog("[HidePile] Pile kept visible - recent removal in progress");
      return;
    }

    // Don't hide while pile row context menu is open (or opening); matches sizer/pile leave behavior
    if (isContextMenuVisible()) {
      debugLog("[HidePile] Pile kept visible - context menu active");
      state.pendingPileClose = true;
      return;
    }

    if (!state.dynamicSizer) return;

    state.dynamicSizer.style.pointerEvents = 'none';
    state.dynamicSizer.style.height = '0px';

    if (state.hoverBridge) {
      state.hoverBridge.style.display = 'none';
    }
    state.dynamicSizer.style.paddingBottom = '0px'; // Remove padding when hiding
    state.dynamicSizer.style.paddingLeft = '0px'; // Remove left padding when hiding

    // Don't hide display in compact mode - let the observer handle it
    // Only hide display if not in compact mode with collapsed sidebar
    const isCompactMode = document.documentElement.getAttribute('zen-compact-mode') === 'true';
    const isSidebarExpanded = document.documentElement.getAttribute('zen-sidebar-expanded') === 'true';
    if (!(isCompactMode && !isSidebarExpanded)) {
      state.dynamicSizer.style.display = 'flex'; // Keep flex but collapsed
    }

    // Hide background and buttons when hiding pile
    hidePileBackground();

    // Fade out pods when hiding
    state.dismissedPods.forEach((_, podKey) => {
      const el = state.podElements.get(podKey);
      if (el) {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
      }
    });

    // Reset mask height variable to -50px (completely hide mask)
    document.documentElement.style.setProperty('--zen-pile-height', '-50px');

    // Remove mask from media controls toolbar when pile collapses
    const mediaControlsToolbar = document.getElementById('zen-media-controls-toolbar');
    if (mediaControlsToolbar) {
      setTimeout(() => {
        mediaControlsToolbar.classList.remove('zen-pile-expanded');
      }, CONFIG.containerAnimationDuration);
    }

    // Restore workspace-arrowscrollbox::after when pile is hidden
    showWorkspaceScrollboxAfter();

    debugLog("Hiding dismissed downloads pile by collapsing sizer");

    document.dispatchEvent(
      new CustomEvent("pile-hidden", { bubbles: true, detail: { reason: "collapsed" } })
    );
  }

  /*
   * Pile visibility state machine (informal invariants):
   * - collapsed: dynamicSizer height 0, --zen-pile-height typically -50px, bridge hidden
   * - expanded:  sizer has row height, mask >= 0 (or 0 when geometry is tiny), pointer-events per always-show
   * - always_visible: getAlwaysShowPile() && dismissedPods.size > 0 ⇒ should not stay collapsed (except compact+sidebar collapsed)
   * - pending_close: pendingPileClose until popuphidden / leave timeout resolves
   * Repair re-syncs mask to sizer and re-applies pointer-events when these drift (e.g. after sticky + pile-shown).
   */

  /**
   * @returns {number}
   */
  function getPileMaskHeightPx() {
    const raw = getComputedStyle(document.documentElement).getPropertyValue("--zen-pile-height").trim();
    const n = parseFloat(raw);
    return Number.isFinite(n) ? n : NaN;
  }

  /**
   * @returns {number}
   */
  function readSizerContentHeightPx() {
    const h = state.dynamicSizer?.style?.height;
    if (!h || h === "0px") {
      return 0;
    }
    const n = parseFloat(h);
    return Number.isFinite(n) ? n : 0;
  }

  /**
   * Fix desynced mask / sizer / pointer-events. Idempotent; logs when it changes something.
   * @param {string} source
   */
  function enforcePileLayoutInvariants(source = "") {
    if (!state.dynamicSizer) {
      return;
    }

    const podCount = state.dismissedPods.size;
    const sizerOpen = state.dynamicSizer.style.height !== "0px";
    const maskH = getPileMaskHeightPx();
    const sizerH = readSizerContentHeightPx();

    if (podCount === 0) {
      if (
        sizerOpen &&
        !state.recentlyRemoved &&
        !state.isEditing &&
        !isContextMenuVisible()
      ) {
        debugLog("[PileRepair] empty pile but sizer open → hidePile", { source });
        hidePile();
      }
      return;
    }

    const isCompactMode = document.documentElement.getAttribute("zen-compact-mode") === "true";
    const isSidebarExpanded = document.documentElement.getAttribute("zen-sidebar-expanded") === "true";
    const compactBlocksPile = isCompactMode && !isSidebarExpanded;

    if (getAlwaysShowPile() && !sizerOpen && !compactBlocksPile) {
      debugLog("[PileRepair] always-show + pods but sizer collapsed → showPile", { source });
      showPile();
      updatePointerEvents();
      return;
    }

    if (sizerOpen && !compactBlocksPile) {
      const maskBadNegative = Number.isFinite(maskH) && maskH < 0;
      const maskZeroButSizerTall = maskH === 0 && sizerH > 16;
      if (maskBadNegative || maskZeroButSizerTall) {
        debugLog("[PileRepair] sizer open but mask out of sync → updatePileHeight", {
          source,
          maskH,
          sizerH
        });
        updatePileHeight();
        updatePointerEvents();
      }
    }
  }

  /**
   * Coalesce rapid calls; throttle how often we run a full enforce pass.
   * @param {string} source
   * @param {number} delayMs
   */
  function schedulePileLayoutRepair(source, delayMs = 80) {
    clearTimeout(state.pileRepairDebounceId);
    state.pileRepairDebounceId = setTimeout(() => {
      state.pileRepairDebounceId = null;
      const now = Date.now();
      if (now - state.lastPileRepairAt < 350) {
        return;
      }
      state.lastPileRepairAt = now;
      try {
        enforcePileLayoutInvariants(source);
      } catch (e) {
        debugLog("[PileRepair] enforce error:", e);
      }
    }, delayMs);
  }

  // Recalculate layout on window resize
  function recalculateLayout() {
    if (state.dismissedPods.size === 0) return;

    // Regenerate grid positions
    state.dismissedPods.forEach((_, podKey) => {
      generateGridPosition(podKey);
    });

    // Recalculate position if pile is currently shown - parent container spans full width
    if (state.dynamicSizer && state.dynamicSizer.style.height !== '0px') {
      // Parent container spans full toolbar width
      state.dynamicSizer.style.left = '0px';
      state.dynamicSizer.style.right = '0px';
      // Remove width when using left/right - it's automatically calculated

      debugLog("Recalculated pile position on resize - full width container");
    }

    // Apply positions for all pods (always single column mode now)
    state.dismissedPods.forEach((_, podKey) => {
      generateGridPosition(podKey);
      applyGridPosition(podKey, 0);
    });

    schedulePileLayoutRepair("resize", 0);
  }

  // Utility: Debounce function
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // --- Pile Container Width Synchronization Logic ---
  function updatePileContainerWidth() {
    if (!state.dynamicSizer) {
      debugLog('[PileWidthSync] dynamicSizer not found. Cannot set width.');
      return;
    }

    const navigatorToolbox = document.getElementById('navigator-toolbox');
    let newWidth = '';

    if (navigatorToolbox) {
      const value = getComputedStyle(navigatorToolbox).getPropertyValue('--zen-sidebar-width').trim();
      if (value && value !== "0px" && value !== "") {
        newWidth = value;
        debugLog('[PileWidthSync] Using --zen-sidebar-width from #navigator-toolbox:', newWidth);
      }
    }

    if (!newWidth) {
      const sidebarBox = document.getElementById('sidebar-box');
      if (sidebarBox && sidebarBox.clientWidth > 0) {
        newWidth = `${sidebarBox.clientWidth}px`;
        debugLog('[PileWidthSync] Using #sidebar-box.clientWidth as fallback:', newWidth);
      } else {
        newWidth = '300px'; // Last resort default
        debugLog('[PileWidthSync] Using default width (300px) as final fallback.');
      }
    }

    // Update the global variable (store raw width, we'll subtract padding when applying)
    state.currentZenSidebarWidthForPile = newWidth;
    debugLog('[PileWidthSync] Stored sidebar width:', newWidth);
  }

  function initPileSidebarWidthSync() {
    // This function is now unused - width is only read on-demand in showPile()
    debugLog('[PileWidthSync] initPileSidebarWidthSync called but automatic sync is disabled to prevent feedback loops.');
  }
  // --- End Pile Container Width Synchronization Logic ---

  // Update downloads button visibility - now handled by hover events
  function updateDownloadsButtonVisibility() {
    // Buttons are now controlled by hover events in showPileBackground/hidePileBackground
    // This function is kept for compatibility but doesn't change visibility
    debugLog(`[DownloadsButton] Button visibility managed by hover - ${state.dismissedPods.size} dismissed pods`);
  }

  // Function to remove a specific download from Firefox downloads list
  async function removeDownloadFromFirefoxList(podData, resolvedDownload = null) {
    try {
      debugLog(`[DeleteDownload] Attempting to remove download from Firefox list: ${podData.filename}`);

      if (
        window.zenTidyDownloads &&
        typeof window.zenTidyDownloads.removeDownloadFromListForPodData === 'function'
      ) {
        const ok = await window.zenTidyDownloads.removeDownloadFromListForPodData(
          podData,
          resolvedDownload
        );
        if (ok) {
          return true;
        }
        debugLog(`[DeleteDownload] API matcher did not remove; falling back to legacy path/URL scan`);
      }

      const list = await window.Downloads.getList(window.Downloads.ALL);
      const downloads = await list.getAll();

      let targetDownload = null;

      for (const download of downloads) {
        if (podData.targetPath && download.target?.path === podData.targetPath) {
          targetDownload = download;
          debugLog(`[DeleteDownload] Found download by target path: ${download.target.path}`);
          break;
        }

        if (podData.sourceUrl && download.source?.url === podData.sourceUrl) {
          const downloadFilename = download.target?.path ?
            download.target.path.split(/[/\\]/).pop() : null;

          if (!downloadFilename || downloadFilename === podData.filename ||
            downloadFilename === podData.originalFilename) {
            targetDownload = download;
            debugLog(`[DeleteDownload] Found download by source URL: ${download.source.url}`);
            break;
          }
        }
      }

      if (targetDownload) {
        await list.remove(targetDownload);
        debugLog(`[DeleteDownload] Successfully removed download from Firefox list: ${podData.filename}`);
        return true;
      }
      debugLog(`[DeleteDownload] Download not found in Firefox list: ${podData.filename}`);
      return false;
    } catch (error) {
      debugLog(`[DeleteDownload] Error removing download from Firefox list:`, error);
      throw error;
    }
  }

  // Function to clear all downloads from Firefox
  async function clearAllDownloads() {
    try {
      debugLog("[ClearAll] Starting to clear all downloads from Firefox");

      // Get the downloads list
      const list = await window.Downloads.getList(window.Downloads.ALL);
      const downloads = await list.getAll();

      debugLog(`[ClearAll] Found ${downloads.length} downloads to clear`);

      // Remove all downloads from the list
      for (const download of downloads) {
        try {
          await list.remove(download);
          debugLog(`[ClearAll] Removed download: ${download.target?.path || download.source?.url}`);
        } catch (error) {
          debugLog(`[ClearAll] Error removing individual download:`, error);
        }
      }

      // Clear the dismissed pile as well since all downloads are gone
      state.dismissedPods.clear();
      updatePileVisibility();
      updateDownloadsButtonVisibility();

      debugLog("[ClearAll] Successfully cleared all downloads and pile");

    } catch (error) {
      debugLog("[ClearAll] Error clearing downloads:", error);
      throw error;
    }
  }

  // Check if main download script has active pods to disable hover
  function shouldDisableHover() {
    try {
      // Check for visible download pods within the dedicated container.
      // Sticky pods (.zen-tidy-sticky-pod) are already in the pile and should NOT disable hover -
      // we want the pile to open so the sticky pod can animate out.
      const podsRowContainer = document.getElementById('userchrome-pods-row-container');
      if (podsRowContainer) {
        const activePods = podsRowContainer.querySelectorAll('.download-pod:not(.zen-tidy-sticky-pod)');
        if (activePods.length > 0) {
          debugLog(`[HoverCheck] Found ${activePods.length} active (non-sticky) pods - disabling pile hover`);
          return true;
        }
      }

      return false;
    } catch (error) {
      debugLog(`[HoverCheck] Error checking main script state:`, error);
      return false;
    }
  }

  // Parse RGB/RGBA from CSS color string - returns { r, g, b, a } or null
  function parseRGB(colorStr) {
    if (!colorStr || typeof colorStr !== 'string') return null;
    if (colorStr.startsWith('rgba(')) {
      const match = colorStr.match(/rgba\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)/);
      if (match) {
        return {
          r: parseInt(match[1]),
          g: parseInt(match[2]),
          b: parseInt(match[3]),
          a: parseFloat(match[4])
        };
      }
    } else if (colorStr.startsWith('rgb(')) {
      const match = colorStr.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
      if (match) {
        return {
          r: parseInt(match[1]),
          g: parseInt(match[2]),
          b: parseInt(match[3]),
          a: 1
        };
      }
    }
    return null;
  }

  // Compute the blended background color that matches Zen's lightening effect
  function computeBlendedBackgroundColor() {
    // Check if we're in compact mode - use toolbar background color directly
    const isCompactMode = document.documentElement.getAttribute('zen-compact-mode') === 'true';
    const isSidebarExpanded = document.documentElement.getAttribute('zen-sidebar-expanded') === 'true';

    if (isCompactMode && isSidebarExpanded) {
      // In compact mode with expanded sidebar, use toolbar background color (includes light tint)
      const navigatorToolbox = document.getElementById('navigator-toolbox');
      if (navigatorToolbox) {
        const toolbarBg = window.getComputedStyle(navigatorToolbox).getPropertyValue('--zen-main-browser-background-toolbar').trim();
        if (toolbarBg) {
          // Try to get the computed color value
          const testEl = document.createElement('div');
          testEl.style.backgroundColor = toolbarBg || 'var(--zen-main-browser-background-toolbar)';
          testEl.style.position = 'absolute';
          testEl.style.visibility = 'hidden';
          document.body.appendChild(testEl);
          const computedColor = window.getComputedStyle(testEl).backgroundColor;
          document.body.removeChild(testEl);

          if (computedColor && computedColor !== 'transparent' && computedColor !== 'rgba(0, 0, 0, 0)') {
            debugLog('[BackgroundColor] Using toolbar background color for compact mode:', computedColor);
            // Ensure fully opaque - convert rgba to rgb if needed
            if (computedColor.startsWith('rgba(')) {
              const match = computedColor.match(/rgba\((\d+),\s*(\d+),\s*(\d+),\s*[\d.]+\)/);
              if (match) {
                return `rgb(${match[1]}, ${match[2]}, ${match[3]})`;
              }
            }
            return computedColor;
          }

          // If computed color isn't available, return the CSS variable
          return toolbarBg || 'var(--zen-main-browser-background-toolbar)';
        }
      }
    }

    // For non-compact mode or collapsed sidebar, use the blended color calculation
    // Get base background color
    const navigatorToolbox = document.getElementById('navigator-toolbox');
    let baseColor = null;
    if (navigatorToolbox) {
      const baseComputed = window.getComputedStyle(navigatorToolbox);
      const baseResolved = baseComputed.getPropertyValue('--zen-main-browser-background').trim();

      // If it's a gradient, we can't easily blend, so return the variable
      if (baseResolved.includes('gradient') || baseResolved.includes('linear') || baseResolved.includes('radial')) {
        return 'var(--zen-main-browser-background)';
      }

      // Try to get the actual computed color
      const testEl = document.createElement('div');
      testEl.style.backgroundColor = 'var(--zen-main-browser-background)';
      testEl.style.position = 'absolute';
      testEl.style.visibility = 'hidden';
      document.body.appendChild(testEl);
      const computedBase = window.getComputedStyle(testEl).backgroundColor;
      document.body.removeChild(testEl);

      if (computedBase && computedBase !== 'transparent' && computedBase !== 'rgba(0, 0, 0, 0)') {
        baseColor = computedBase;
      }
    }

    // Get wrapper background color
    const appWrapper = document.getElementById('zen-main-app-wrapper');
    let wrapperColor = null;
    if (appWrapper) {
      const wrapperComputed = window.getComputedStyle(appWrapper);
      wrapperColor = wrapperComputed.backgroundColor;
    }

    // If we don't have both colors, fallback to base
    if (!baseColor || !wrapperColor || baseColor === 'transparent' || wrapperColor === 'transparent') {
      return 'var(--zen-main-browser-background)';
    }

    const baseRGB = parseRGB(baseColor);
    const wrapperRGB = parseRGB(wrapperColor);

    if (!baseRGB || !wrapperRGB) {
      return 'var(--zen-main-browser-background)';
    }

    // Blend the colors to achieve the target: rgb(49, 32, 42)
    // Formula: blended = base * (1 - ratio) + wrapper * ratio
    // Solving for ratio to match target rgb(49, 32, 42):
    // If base is rgb(34, 17, 31) and wrapper is rgb(255, 233, 198):
    // - R: 34 + (255-34) * ratio = 49 => ratio ≈ 0.068
    // - G: 17 + (233-17) * ratio = 32 => ratio ≈ 0.069  
    // - B: 31 + (198-31) * ratio = 42 => ratio ≈ 0.066
    // Average ratio ≈ 0.067 (about 6.7%)
    const wrapperRatio = 0.067; // Adjusted to match target rgb(49, 32, 42)

    const blendedR = Math.round(baseRGB.r * (1 - wrapperRatio) + wrapperRGB.r * wrapperRatio);
    const blendedG = Math.round(baseRGB.g * (1 - wrapperRatio) + wrapperRGB.g * wrapperRatio);
    const blendedB = Math.round(baseRGB.b * (1 - wrapperRatio) + wrapperRGB.b * wrapperRatio);

    // Always return fully opaque color (no transparency)
    return `rgb(${blendedR}, ${blendedG}, ${blendedB})`;
  }

  // Calculate text color based on background color (using Zen's luminance/contrast logic)
  function calculateTextColorForBackground(backgroundColor) {
    const parsed = parseRGB(backgroundColor);
    const bgRGB = parsed ? [parsed.r, parsed.g, parsed.b] : null;
    if (!bgRGB) {
      // Fallback to CSS variable if we can't parse
      return 'var(--zen-text-color, #e0e0e0)';
    }

    // Calculate relative luminance (from Zen's luminance function)
    function luminance([r, g, b]) {
      const a = [r, g, b].map((v) => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      });
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    }

    // Calculate contrast ratio (from Zen's contrastRatio function)
    function contrastRatio(rgb1, rgb2) {
      const lum1 = luminance(rgb1);
      const lum2 = luminance(rgb2);
      const brightest = Math.max(lum1, lum2);
      const darkest = Math.min(lum1, lum2);
      return (brightest + 0.05) / (darkest + 0.05);
    }

    // Test dark text (black) and light text (white)
    const darkText = [0, 0, 0];
    const lightText = [255, 255, 255];

    const darkContrast = contrastRatio(bgRGB, darkText);
    const lightContrast = contrastRatio(bgRGB, lightText);

    // Use whichever has better contrast
    // Also consider: if background is very light, use dark text; if very dark, use light text
    const bgLuminance = luminance(bgRGB);
    const useDarkText = darkContrast > lightContrast || bgLuminance > 0.5;

    if (useDarkText) {
      return 'rgba(0, 0, 0, 0.8)'; // Dark text with some transparency
    } else {
      return 'rgba(255, 255, 255, 0.8)'; // Light text with some transparency
    }
  }

  // Update text colors for all pod rows based on current background
  function updatePodTextColors() {
    if (!state.dynamicSizer) {
      return;
    }

    const blendedColor = computeBlendedBackgroundColor();
    const textColor = calculateTextColorForBackground(blendedColor);

    // Update all pod text elements
    const textElements = state.pileContainer.querySelectorAll('.dismissed-pod-filename, .dismissed-pod-filesize');
    textElements.forEach(el => {
      el.style.color = textColor;
    });

    console.log('[ShowPile] Updated text colors to:', textColor, 'for background:', blendedColor);
  }

  // applyTabsWrapperMask and removeTabsWrapperMask function removed - logic replaced by CSS mask-image with --zen-pile-height variable

  // Show pile background on hover
  // dynamicSizer stays transparent in all modes so the mask on #zen-tabs-wrapper reveals the titlebar underneath
  function showPileBackground() {
    if (!state.dynamicSizer) return;

    state.dynamicSizer.style.backgroundColor = 'transparent';
    state.dynamicSizer.style.background = 'transparent';
    state.dynamicSizer.style.backdropFilter = 'none';
    state.dynamicSizer.style.webkitBackdropFilter = 'none';
    updatePodTextColors();
  }

  // Hide pile background when not hovering
  function hidePileBackground() {
    if (!state.dynamicSizer) {
      return;
    }
    if (state.isTransitioning) {
      return;
    }
    
    // Don't hide background if pile is currently visible - keep mask persistent
    const isPileVisible = state.dynamicSizer.style.height !== '0px' && state.dismissedPods.size > 0;
    if (isPileVisible) {
      // Keep the background and mask active while pile is visible
      debugLog("[HidePileBackground] Pile is visible - keeping mask persistent");
      return;
    }
    
    // Don't hide background if user is currently hovering over pile area
    if (state.downloadButton?.matches(':hover') || isHoveringPileArea()) {
      debugLog("[HidePileBackground] User hovering over pile area - keeping mask active");
      return;
    }
    
    // Only hide background when pile is actually hidden and no hover
    state.dynamicSizer.style.background = 'transparent';
    state.dynamicSizer.style.backgroundColor = 'transparent';
    debugLog("[HidePileBackground] Background hidden - pile not visible and no hover");
  }

  // Hide arrowscrollbox.workspace-arrowscrollbox::after when pile is showing
  function hideWorkspaceScrollboxAfter() {
    if (state.workspaceScrollboxStyle) {
      document.documentElement.style.setProperty('--zen-stuff-scrollbox-after-opacity', '0');
      debugLog("Hidden arrowscrollbox.workspace-arrowscrollbox::after");
    }
  }

  // Show arrowscrollbox.workspace-arrowscrollbox::after when pile is hidden
  function showWorkspaceScrollboxAfter() {
    if (state.workspaceScrollboxStyle) {
      document.documentElement.style.setProperty('--zen-stuff-scrollbox-after-opacity', '1');
      debugLog("Shown arrowscrollbox.workspace-arrowscrollbox::after");
    }
  }

  // Helper: is cursor over pile area (including bridge between button and pile)
  function isHoveringPileArea() {
    return state.pileContainer?.matches(':hover') ||
           state.dynamicSizer?.matches(':hover') ||
           state.hoverBridge?.matches(':hover');
  }

  // Hover bridge enter - keeps pile visible when moving from download button to pile
  function handleHoverBridgeEnter() {
    debugLog("[HoverBridge] Entered - keeping pile visible");
    clearTimeout(state.hoverTimeout);
    if (state.dismissedPods.size > 0) {
      showPile();
      showPileBackground();
    }
  }

  // Hover bridge leave - same logic as dynamicSizer leave
  // Use a short delay so pile's mouseenter can fire first when moving bridge→pile (avoids premature hide)
  function handleHoverBridgeLeave(event) {
    debugLog("[HoverBridge] Left");
    if (event?.relatedTarget && (state.pileContainer?.contains(event.relatedTarget) || state.dynamicSizer?.contains(event.relatedTarget))) {
      debugLog("[HoverBridge] Moving into pile - not scheduling hide");
      return;
    }
    // Delay before delegating so pile's mouseenter has time to fire when moving upward
    const bridgeLeaveGraceMs = 120;
    setTimeout(() => {
      if (isHoveringPileArea() || state.downloadButton?.matches(':hover')) return;
      handleDynamicSizerLeave(event);
    }, bridgeLeaveGraceMs);
  }

  // Setup hover events for background/buttons (simplified - always single column mode)
  function setupPileBackgroundHoverEvents() {
    if (!state.dynamicSizer || !state.pileContainer) {
      return;
    }

    // Remove existing hover events first
    if (state.containerHoverEventsAttached) {
      state.dynamicSizer.removeEventListener('mouseenter', handleDynamicSizerHover);
      state.dynamicSizer.removeEventListener('mouseleave', handleDynamicSizerLeave);
      state.containerHoverEventsAttached = false;
    }

    if (state.pileHoverEventsAttached) {
      state.pileContainer.removeEventListener('mouseenter', handlePileHover);
      state.pileContainer.removeEventListener('mouseleave', handlePileLeave);
      state.pileHoverEventsAttached = false;
    }

    if (state.hoverBridge) {
      state.hoverBridge.removeEventListener('mouseenter', handleHoverBridgeEnter);
      state.hoverBridge.removeEventListener('mouseleave', handleHoverBridgeLeave);
      state.hoverBridge.addEventListener('mouseenter', handleHoverBridgeEnter);
      state.hoverBridge.addEventListener('mouseleave', handleHoverBridgeLeave);
    }

    // Attach both: dynamicSizer (overall area) and pileContainer (pile rows) so mask stays when hovering rows
    state.dynamicSizer.addEventListener('mouseenter', handleDynamicSizerHover);
    state.dynamicSizer.addEventListener('mouseleave', handleDynamicSizerLeave);
    state.containerHoverEventsAttached = true;

    state.pileContainer.addEventListener('mouseenter', handlePileHover);
    state.pileContainer.addEventListener('mouseleave', handlePileLeave);
    state.pileHoverEventsAttached = true;
  }

  // Alt key handlers for always-show mode
  function handleKeyDown(event) {
    if (event.key === 'Alt' && !state.isAltPressed) {
      state.isAltPressed = true;
      debugLog("[AlwaysShow] Alt key pressed");

      if (getAlwaysShowPile() && state.dismissedPods.size > 0) {
        // Hide pile when Alt is pressed in always-show mode
        hidePile();
      }
    }
  }

  function handleKeyUp(event) {
    if (event.key === 'Alt' && state.isAltPressed) {
      state.isAltPressed = false;
      debugLog("[AlwaysShow] Alt key released");

      if (getAlwaysShowPile() && state.dismissedPods.size > 0) {
        // Show pile again when Alt is released in always-show mode
        showPile();
      }
    }
  }

  // Check if pile should be visible based on always-show mode and Alt key state
  function shouldPileBeVisible() {
    if (state.dismissedPods.size === 0) return false;

    if (getAlwaysShowPile()) {
      // In always-show mode: visible unless Alt is pressed
      return !state.isAltPressed;
    } else {
      // Normal hover mode: only visible when hovering
      return false; // This will be overridden by hover handlers
    }
  }

  // Get preference values with defaults
  function getAlwaysShowPile() {
    try {
      // Changed default to false as requested
      return Services.prefs.getBoolPref(PREFS.alwaysShowPile, false);
    } catch (e) {
      debugLog("Error reading always-show-pile preference, using default (false):", e);
      return false;
    }
  }

  // Get library button preference
  function getUseLibraryButton() {
    try {
      const value = Services.prefs.getBoolPref(PREFS.useLibraryButton, false);
      console.log(`[Zen Stuff] getUseLibraryButton() returning: ${value}`);
      console.log(`[Zen Stuff] Preference name: ${PREFS.useLibraryButton}`);
      
      // Debug: Check what buttons are available
      const libraryBtn = document.getElementById('zen-library-button');
      const downloadsBtn = document.getElementById('downloads-button');
      console.log(`[Zen Stuff] Available buttons - Library: ${!!libraryBtn}, Downloads: ${!!downloadsBtn}`);
      
      return value;
    } catch (e) {
      console.log(`[Zen Stuff] Error reading use-library-button preference, using default (false):`, e);
      debugLog("Error reading use-library-button preference, using default (false):", e);
      return false;
    }
  }

  // Setup compact mode observer to handle visibility changes
  function setupCompactModeObserver() {
    const mainWindow = document.getElementById('main-window');
    const zenMainAppWrapper = document.getElementById('zen-main-app-wrapper');
    const targetElement = zenMainAppWrapper || document.documentElement;

    if (!targetElement) {
      debugLog("[CompactModeObserver] Target element not found, cannot set up observer");
      return;
    }

    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          const attributeName = mutation.attributeName;
          if (attributeName === 'zen-compact-mode' || attributeName === 'zen-sidebar-expanded') {
            debugLog(`[CompactModeObserver] ${attributeName} changed, updating pile visibility`);
            // Update pile visibility based on compact mode state
            if (state.dynamicSizer && state.dismissedPods.size > 0) {
              const isCompactMode = document.documentElement.getAttribute('zen-compact-mode') === 'true';
              const isSidebarExpanded = document.documentElement.getAttribute('zen-sidebar-expanded') === 'true';

              if (isCompactMode && !isSidebarExpanded) {
                // Hide pile when sidebar is collapsed in compact mode
                state.dynamicSizer.style.display = 'none';
              } else if (shouldPileBeVisible()) {
                // Show pile if it should be visible
                showPile();
              }
            }
          }
        }
      }
    });

    observer.observe(targetElement, {
      attributes: true,
      attributeFilter: ['zen-compact-mode', 'zen-sidebar-expanded']
    });

    // Also observe documentElement for zen-sidebar-expanded
    if (targetElement !== document.documentElement) {
      observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['zen-sidebar-expanded']
      });
    }

    debugLog("[CompactModeObserver] Set up observer for compact mode changes");
  }

  // Setup preference change listener
  function setupPreferenceListener() {
    try {
      const prefObserver = {
        observe: function (subject, topic, data) {
          if (topic === 'nsPref:changed') {
            if (data === PREFS.alwaysShowPile) {
              const newValue = getAlwaysShowPile();
              debugLog(`[Preferences] Always-show-pile preference changed to: ${newValue}`);
              handleAlwaysShowPileChange(newValue);
            } else if (data === PREFS.useLibraryButton) {
              const newValue = getUseLibraryButton();
              console.log(`[Zen Stuff] Use-library-button preference changed to: ${newValue}`);
              debugLog(`[Preferences] Use-library-button preference changed to: ${newValue}`);
              // Re-find the download button with new preference (with retry for custom buttons)
              findDownloadButton().catch(error => {
                console.error('[Preferences] Error re-finding download button:', error);
              });
            }
          }
        }
      };

      Services.prefs.addObserver(PREFS.alwaysShowPile, prefObserver, false);
      Services.prefs.addObserver(PREFS.useLibraryButton, prefObserver, false);
      debugLog("[Preferences] Added observers for preferences");

      // Store observer for cleanup
      state.prefObserver = prefObserver;
    } catch (e) {
      debugLog("[Preferences] Error setting up preference observer:", e);
    }
  }

  // Handle preference change
  function handleAlwaysShowPileChange(newValue) {
    debugLog(`[Preferences] Handling always-show-pile change to: ${newValue}`);

    if (state.dismissedPods.size === 0) {
      debugLog("[Preferences] No dismissed pods, nothing to do");
      return;
    }

    if (newValue) {
      // Switched to always-show mode
      if (shouldPileBeVisible()) {
        showPile();
        debugLog("[Preferences] Switched to always-show mode - showing pile");
      }
    } else {
      // Switched to hover mode
      if (state.dynamicSizer && state.dynamicSizer.style.height !== '0px') {
        // If pile is currently visible, hide it (it will show again on hover)
        hidePile();
        debugLog("[Preferences] Switched to hover mode - hiding pile");
      }
    }
  }

  // Update pointer-events based on current state
  function updatePointerEvents() {
    if (!state.dynamicSizer || !state.pileContainer) return;
    const alwaysShow = getAlwaysShowPile();
    if (alwaysShow) {
      state.dynamicSizer.style.pointerEvents = 'none';
      state.pileContainer.style.pointerEvents = 'auto';
    } else {
      state.dynamicSizer.style.pointerEvents = 'auto';
      state.pileContainer.style.pointerEvents = 'auto';
    }
  }

  // --- Native XUL menupopup for pod context menu ---
  const podContextMenuFragment = window.MozXULElement.parseXULToFragment(`
    <menupopup id="zen-pile-pod-context-menu">
      <menuitem id="zenPilePodOpen" label="Open"/>
      <menuitem id="zenPilePodRename" label="Rename"/>
      <menuitem id="zenPilePodCopy" label="Copy to Clipboard"/>
      <menuseparator/>
      <menuitem id="zenPilePodRemove" label="Remove from Stuff"/>
      <menuitem id="zenPilePodDelete" label="Delete"/>
    </menupopup>
  `);
  let podContextMenu = null;
  let podContextMenuPodData = null;

  function ensurePodContextMenu() {
    if (!podContextMenu) {
      const frag = podContextMenuFragment.cloneNode(true);
      podContextMenu = frag.firstElementChild;
      document.getElementById("mainPopupSet")?.appendChild(podContextMenu) || document.body.appendChild(podContextMenu);
      // Open
      podContextMenu.querySelector("#zenPilePodOpen").addEventListener("command", () => {
        if (podContextMenuPodData) openPodFile(podContextMenuPodData);
      });
      // Rename (trigger inline editing)
      podContextMenu.querySelector("#zenPilePodRename").addEventListener("command", () => {
        if (podContextMenuPodData) {
          startInlineRename(podContextMenuPodData);
        }
      });
      // Remove from Stuff
      podContextMenu.querySelector("#zenPilePodRemove").addEventListener("command", async () => {
        if (podContextMenuPodData) {
          // Ask for confirmation (use Services.prompt with window so it works from context menu)
          const confirmed = Services.prompt.confirm(
            window,
            'Remove from Stuff',
            `Are you sure you want to remove "${podContextMenuPodData.filename}" from Stuff?\n\nThis will remove it from the pile but won't delete the file.`
          );
          if (!confirmed) {
            return; // User cancelled
          }
          
          try {
            window.zenTidyDownloads.permanentDelete(podContextMenuPodData.key);
            removePodFromPile(podContextMenuPodData.key);
            // --- Update carousel/grid after removal ---
            const allPods = Array.from(state.dismissedPods.keys()).reverse(); // Most recent first
            const MAX_PODS_TO_SHOW = 10;
            if (allPods.length < MAX_PODS_TO_SHOW) {
              state.carouselStartIndex = 0;
              state.visibleGridOrder = allPods.slice();
            } else {
              // If carouselStartIndex is out of bounds, reset
              if (state.carouselStartIndex >= allPods.length) {
                state.carouselStartIndex = 0;
              }
              state.visibleGridOrder = [];
              for (let i = 0; i < MAX_PODS_TO_SHOW; i++) {
                const podIndex = state.carouselStartIndex + i;
                if (podIndex < allPods.length) {
                  state.visibleGridOrder.push(allPods[podIndex]);
                }
              }
            }
            // Update positions for all pods
            state.dismissedPods.forEach((_, podKey) => {
              generateGridPosition(podKey);
              applyGridPosition(podKey, 0);
            });
            // Immediately hide all non-visible pods after removal
            state.dismissedPods.forEach((_, podKey) => {
              if (!state.visibleGridOrder.includes(podKey)) {
                const podElement = state.podElements.get(podKey);
                if (podElement) podElement.style.display = 'none';
              }
            });
          } catch (err) {
            showUserNotification(`Error removing pod: ${err.message}`);
          }
        }
      });

      // Add the popuphidden event listener here, after podContextMenu is created
      podContextMenu.addEventListener("popuphidden", () => {
        state.pileContextMenuActive = false;
        setTimeout(() => {
          const isHoveringPile = isHoveringPileArea();
          const isHoveringDownloadArea = state.downloadButton?.matches(':hover');
          const isPileVisible = state.dynamicSizer && state.dynamicSizer.style.height !== '0px';

          if (!isHoveringPile && !isHoveringDownloadArea) {
            // No mode transitions needed
            if (!getAlwaysShowPile()) {
              // --- handle pending pile close ---
              if (state.pendingPileClose) {
                debugLog('[ContextMenu] popuphidden: pendingPileClose was set, closing pile now');
                hidePile();
                state.pendingPileClose = false;
              } else {
                hidePile();
              }
            }
          } else {
            // If still hovering, just clear the flag
            state.pendingPileClose = false;
          }
          schedulePileLayoutRepair("contextmenu-popuphidden", 150);
        }, 100);
      });

      // Copy to Clipboard
      podContextMenu.querySelector("#zenPilePodCopy").addEventListener("command", async () => {
        if (podContextMenuPodData) {
          try {
            await copyPodFileToClipboard(podContextMenuPodData);
          } catch (err) {
            showUserNotification(`Error copying file to clipboard: ${err.message}`);
          }
        }
      });

      // Delete File
      podContextMenu.querySelector("#zenPilePodDelete").addEventListener("command", async () => {
        if (podContextMenuPodData) {
          try {
            await deletePodFile(podContextMenuPodData);
          } catch (err) {
            showUserNotification(`Error deleting file: ${err.message}`);
          }
        }
      });
    }
  }

  // Cleanup function to prevent memory leaks
  function cleanup() {
    debugLog("Cleaning up dismissed downloads pile system");

    try {
      // Clear all timeouts
      if (state.hoverTimeout) {
        clearTimeout(state.hoverTimeout);
        state.hoverTimeout = null;
      }
      if (state.pileRepairDebounceId) {
        clearTimeout(state.pileRepairDebounceId);
        state.pileRepairDebounceId = null;
      }
      if (state.pileLayoutRepairIntervalId) {
        clearInterval(state.pileLayoutRepairIntervalId);
        state.pileLayoutRepairIntervalId = null;
      }

      // Remove all event listeners
      EventManager.cleanupAll();

      // Remove preference observer
      if (state.prefObserver) {
        try {
          Services.prefs.removeObserver(PREFS.alwaysShowPile, state.prefObserver);
          Services.prefs.removeObserver(PREFS.useLibraryButton, state.prefObserver);
        } catch (error) {
          console.warn('[Cleanup] Error removing preference observers:', error);
        }
        state.prefObserver = null;
      }

      // Remove DOM elements (bridge is not inside dynamicSizer — remove both)
      if (state.hoverBridge && state.hoverBridge.parentNode) {
        state.hoverBridge.parentNode.removeChild(state.hoverBridge);
      }
      state.hoverBridge = null;
      if (state.dynamicSizer && state.dynamicSizer.parentNode) {
        state.dynamicSizer.parentNode.removeChild(state.dynamicSizer);
      }
      state.dynamicSizer = null;

      // Clear all state
      state.clearAll();
      state.isInitialized = false;

      // Remove global references
      if (window.zenPileContextMenu) {
        window.zenPileContextMenu = null;
      }

      debugLog("Cleanup completed successfully");
    } catch (error) {
      ErrorHandler.handleError(error, 'cleanup');
    }
  }

  // Enhanced file operations with proper error handling
  async function openPodFile(podData) {
    debugLog(`Attempting to open file: ${podData.key}`);

    try {
      validatePodData(podData);

      if (!podData.targetPath) {
        throw new Error('No file path available');
      }

      const fileExists = await FileSystem.fileExists(podData.targetPath);
      if (fileExists) {
        const file = await FileSystem.createFileInstance(podData.targetPath);
        file.launch();
        debugLog(`Successfully opened file: ${podData.filename}`);
      } else {
        // File doesn't exist, try to open the containing folder
        const parentDir = await FileSystem.getParentDirectory(podData.targetPath);
        if (parentDir && parentDir.exists()) {
          parentDir.launch();
          debugLog(`File not found, opened containing folder: ${podData.filename}`);
        } else {
          throw new Error('File and folder not found');
        }
      }
    } catch (error) {
      ErrorHandler.handleError(error, 'openPodFile');
      debugLog(`Error opening file: ${podData.filename}`, error);
    }
  }

  // Enhanced file explorer function
  async function showPodFileInExplorer(podData) {
    debugLog(`Attempting to show file in file explorer: ${podData.key}`);

    try {
      validatePodData(podData);

      if (!podData.targetPath) {
        throw new Error('No file path available');
      }

      const fileExists = await FileSystem.fileExists(podData.targetPath);
      if (fileExists) {
        const file = await FileSystem.createFileInstance(podData.targetPath);

        try {
          // Try to reveal the file in the file manager
          file.reveal();
          debugLog(`Successfully showed file in explorer: ${podData.filename}`);
        } catch (revealError) {
          // If reveal() doesn't work, fall back to opening the containing folder
          debugLog(`Reveal failed, trying to open containing folder: ${revealError}`);
          const parentDir = await FileSystem.getParentDirectory(podData.targetPath);
          if (parentDir && parentDir.exists()) {
            parentDir.launch();
            debugLog(`Opened containing folder: ${podData.filename}`);
          } else {
            throw new Error('Containing folder not found');
          }
        }
      } else {
        // File doesn't exist, try to open the containing folder
        const parentDir = await FileSystem.getParentDirectory(podData.targetPath);
        if (parentDir && parentDir.exists()) {
          parentDir.launch();
          debugLog(`File not found, opened containing folder: ${podData.filename}`);
        } else {
          throw new Error('File and folder not found');
        }
      }
    } catch (error) {
      ErrorHandler.handleError(error, 'showPodFileInExplorer');
      debugLog(`Error showing file in explorer: ${podData.filename}`, error);
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === "complete") {
    init();
  } else {
    window.addEventListener("load", init, { once: true });
  }

  // Cleanup on page unload
  window.addEventListener("beforeunload", cleanup, { once: true });

  debugLog("Dismissed downloads pile script loaded");


  // --- Start inline rename editing ---
  function startInlineRename(podData) {
    const podElement = state.getPodElement(podData.key);
    if (!podElement) {
      debugLog(`[Rename] Cannot start inline rename - pod element not found: ${podData.key}`);
      return;
    }
    
    const filenameElement = podElement.querySelector('.dismissed-pod-filename');
    if (!filenameElement) {
      debugLog(`[Rename] Cannot start inline rename - filename element not found`);
      return;
    }
    
    // Check if already editing
    if (state.isEditing) {
      debugLog(`[Rename] Already editing a filename`);
      return;
    }
    
    state.isEditing = true; // Prevent pile from hiding during editing
    
    // Ensure pile is visible during editing
    if (state.dynamicSizer && state.dismissedPods.size > 0) {
      showPile();
    }
    
    const originalText = filenameElement.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.value = originalText;
    input.style.cssText = `
      width: 100%;
      padding: 0;
      border: none;
      border-radius: 0;
      background: transparent;
      color: var(--zen-text-color, #e0e0e0);
      font-size: 12px;
      font-weight: 500;
      font-family: inherit;
      margin-bottom: 2px;
      box-sizing: border-box;
      outline: none;
    `;
    
    // Select filename without extension
    const lastDotIndex = originalText.lastIndexOf('.');
    if (lastDotIndex > 0) {
      input.setSelectionRange(0, lastDotIndex);
    } else {
      input.select();
    }
    
    // Replace filename with input
    const parent = filenameElement.parentNode;
    parent.replaceChild(input, filenameElement);
    input.focus();
    
    const finishEditing = async (save = false) => {
      if (!state.isEditing) return;
      state.isEditing = false; // Allow pile to hide again after editing
      
      const newName = input.value.trim();
      if (save && newName && newName !== originalText) {
        try {
          debugLog(`[Rename] Inline rename: ${originalText} -> ${newName}`);
          await renamePodFile(podData, newName);
        } catch (error) {
          debugLog(`[Rename] Error renaming file:`, error);
          showUserNotification(`Error renaming file: ${error.message}`);
          // Restore original text on error
          input.value = originalText;
        }
      }
      
      // Restore filename element
      filenameElement.textContent = podData.filename || originalText;
      parent.replaceChild(filenameElement, input);
      
      // Check if we should hide the pile after editing (if not hovering)
      if (!getAlwaysShowPile() && !shouldDisableHover()) {
        // Small delay to allow DOM to update
        setTimeout(() => {
          const isHoveringDownloadArea = state.downloadButton?.matches(':hover');
          const isHoveringPile = isHoveringPileArea();
          
          // Only hide if not hovering over download button or pile
          if (!isHoveringDownloadArea && !isHoveringPile) {
            debugLog("[Rename] Editing finished, hiding pile (not hovering)");
            clearTimeout(state.hoverTimeout);
            state.hoverTimeout = setTimeout(() => {
              hidePile();
            }, CONFIG.hoverDebounceMs);
          }
        }, 50);
      }
    };
    
    input.addEventListener('blur', () => finishEditing(true));
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        finishEditing(true);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        finishEditing(false);
      }
    });
  }

  // --- Global pod file rename logic ---
  async function renamePodFile(podData, newFilename) {
    try {
      validatePodData(podData);
      if (!newFilename || typeof newFilename !== 'string') {
        throw new Error('Invalid new filename');
      }
      if (!podData.targetPath) {
        throw new Error('No file path available for renaming');
      }
      // Use the FileSystem utility for safe file operations (auto-increment)
      const newPath = await FileSystem.renameFile(podData.targetPath, newFilename);
      // Update pod data
      const oldFilename = podData.filename;
      // Extract the actual new filename from the path
      const newName = newPath.split(/[/\\]/).pop();
      podData.filename = newName;
      podData.targetPath = newPath;
      // Update the pod in our local storage
      state.setPodData(podData.key, podData);
      // Save updated pod data to SessionStore for persistence
      saveDismissedPodToSession(podData);
      // Update the pod element
      const podElement = state.getPodElement(podData.key);
      if (podElement) {
        podElement.title = `${newName}\nClick: Open file\nMiddle-click: Show in file explorer\nRight-click: Context menu`;

        // Update the displayed filename in the DOM
        const filenameElement = podElement.querySelector('.dismissed-pod-filename');
        if (filenameElement) {
          filenameElement.textContent = newName;
          debugLog(`[Rename] Updated displayed filename in DOM: ${newName}`);
        }

        // Force UI refresh if needed (e.g., update label/icon)
        if (podElement.querySelector('.dismissed-pod-preview')) {
          // Optionally update preview/icon if needed
          // podElement.querySelector('.dismissed-pod-preview').textContent = getFileIcon(podData.contentType);
        }
      }
      // Try to update the main script's dismissed pods if the API exists
      if (window.zenTidyDownloads && window.zenTidyDownloads.dismissedPods) {
        try {
          const mainScriptPod = window.zenTidyDownloads.dismissedPods.get(podData.key);
          if (mainScriptPod) {
            mainScriptPod.filename = newName;
            mainScriptPod.targetPath = newPath;
            window.zenTidyDownloads.dismissedPods.set(podData.key, mainScriptPod);
            debugLog(`[Rename] Updated main script pod data`);
          }
        } catch (error) {
          debugLog(`[Rename] Could not update main script pod data:`, error);
        }
      }
      // Try to update Firefox downloads list
      try {
        const list = await window.Downloads.getList(window.Downloads.ALL);
        const downloads = await list.getAll();
        // Find the download that matches our pod
        const targetDownload = downloads.find(download =>
          download.target?.path === podData.targetPath.replace(newName, oldFilename) ||
          (download.source?.url === podData.sourceUrl &&
            download.target?.path?.endsWith(oldFilename))
        );
        if (targetDownload && targetDownload.target) {
          targetDownload.target.path = newPath;
          debugLog(`[Rename] Updated Firefox download record`);
        }
      } catch (error) {
        debugLog(`[Rename] Could not update Firefox download record:`, error);
      }
      debugLog(`[Rename] Successfully renamed file: ${oldFilename} -> ${newName}`);
    } catch (error) {
      showUserNotification(`Error renaming file: ${error.message}`);
      throw error;
    }
  }

  // --- Helper for user notifications ---
  function showUserNotification(message, type = 'error') {
    // Simple alert for now; could be replaced with a custom toast/notification
    alert(message);
  }

  // --- Enhanced filename validation ---
  function isValidFilename(name) {
    // Windows forbidden chars: \\ / : * ? " < > |
    // Also disallow empty or all-whitespace
    return (
      typeof name === 'string' &&
      name.trim().length > 0 &&
      !/[\\/:*?"<>|]/.test(name)
    );
  }

  // --- Clipboard file copy logic ---
  async function copyPodFileToClipboard(podData) {
    debugLog(`[Clipboard] Attempting to copy file to clipboard: ${podData.filename}`);
    try {
      validatePodData(podData);
      if (!podData.targetPath) {
        throw new Error('No file path available');
      }
      const fileExists = await FileSystem.fileExists(podData.targetPath);
      if (!fileExists) {
        throw new Error('File does not exist');
      }
      // Get nsIFile instance
      const file = await FileSystem.createFileInstance(podData.targetPath);
      // Prepare transferable
      const transferable = Components.classes["@mozilla.org/widget/transferable;1"].createInstance(Components.interfaces.nsITransferable);
      transferable.init(null);
      // Add file flavor
      transferable.addDataFlavor("application/x-moz-file");
      transferable.setTransferData("application/x-moz-file", file);
      // Get clipboard
      const clipboard = Components.classes["@mozilla.org/widget/clipboard;1"].getService(Components.interfaces.nsIClipboard);
      clipboard.setData(transferable, null, Components.interfaces.nsIClipboard.kGlobalClipboard);
      debugLog(`[Clipboard] File copied to clipboard: ${podData.filename}`);
    } catch (error) {
      ErrorHandler.handleError(error, 'copyPodFileToClipboard');
      throw error;
    }
  }

  // --- Delete file from system ---
  async function deletePodFile(podData) {
    debugLog(`[DeleteFile] Attempting to delete file from system: ${podData.filename}`);
    try {
      validatePodData(podData);

      const confirmed = Services.prompt.confirm(
        window,
        'Delete File',
        `Are you sure you want to permanently delete "${podData.filename}"?\n\nThis action cannot be undone.`
      );

      if (!confirmed) {
        debugLog(`[DeleteFile] User cancelled deletion`);
        return;
      }

      let resolvedDownload = null;
      if (
        window.zenTidyDownloads &&
        typeof window.zenTidyDownloads.resolveDownloadFromPodData === 'function'
      ) {
        try {
          resolvedDownload = await window.zenTidyDownloads.resolveDownloadFromPodData(podData);
        } catch (resolveErr) {
          debugLog(`[DeleteFile] resolveDownloadFromPodData failed:`, resolveErr);
        }
      }

      const pathCandidates = [];
      if (resolvedDownload?.target?.path) {
        pathCandidates.push(resolvedDownload.target.path);
      }
      if (podData.targetPath) {
        pathCandidates.push(podData.targetPath);
      }
      const uniquePaths = [...new Set(pathCandidates.filter(Boolean))];

      let pathToDelete = null;
      for (const p of uniquePaths) {
        if (await FileSystem.fileExists(p)) {
          pathToDelete = p;
          break;
        }
      }

      if (!pathToDelete) {
        debugLog(
          `[DeleteFile] No file at Firefox-reported or saved path; clearing pile and downloads entry only: ${podData.filename}`
        );
        try {
          await removeDownloadFromFirefoxList(podData, resolvedDownload);
        } catch (error) {
          debugLog(`[DeleteFile] Could not remove from Firefox downloads list:`, error);
        }
        removePodFromPile(podData.key);
        if (window.zenTidyDownloads && window.zenTidyDownloads.dismissedPods) {
          try {
            window.zenTidyDownloads.dismissedPods.delete(podData.key);
          } catch (error) {
            debugLog(`[DeleteFile] Could not remove from main script dismissed pods:`, error);
          }
        }
        return;
      }

      const deleted = await FileSystem.deleteFile(pathToDelete);
      if (!deleted) {
        throw new Error('File deletion failed');
      }

      debugLog(`[DeleteFile] Successfully deleted file at ${pathToDelete}: ${podData.filename}`);

      try {
        await removeDownloadFromFirefoxList(podData, resolvedDownload);
      } catch (error) {
        debugLog(`[DeleteFile] Could not remove from Firefox downloads list:`, error);
      }

      removePodFromPile(podData.key);

      if (window.zenTidyDownloads && window.zenTidyDownloads.dismissedPods) {
        try {
          window.zenTidyDownloads.dismissedPods.delete(podData.key);
          debugLog(`[DeleteFile] Removed from main script dismissed pods`);
        } catch (error) {
          debugLog(`[DeleteFile] Could not remove from main script dismissed pods:`, error);
        }
      }
    } catch (error) {
      ErrorHandler.handleError(error, 'deletePodFile');
      throw error;
    }
  }

  // Utility to check if the pod context menu is visible (or opening)
  function isContextMenuVisible() {
    if (state.pileContextMenuActive) return true;
    const menu = document.getElementById('zen-pile-pod-context-menu');
    return Boolean(menu && typeof menu.state === 'string' && menu.state === 'open');
  }

  /* Add CSS for flyout/flyin animations */
  const zenFlyAnimStyle = document.createElement('style');
  zenFlyAnimStyle.textContent = `
  .zen-flyin-right {
    animation: zen-flyin-right 0.4s cubic-bezier(0.4,0,0.2,1) both;
  }
  .zen-flyin-left {
    animation: zen-flyin-left 0.4s cubic-bezier(0.4,0,0.2,1) both;
  }
  .zen-flyout-right {
    animation: zen-flyout-right 0.4s cubic-bezier(0.4,0,0.2,1) both;
  }
  .zen-flyout-left {
    animation: zen-flyout-left 0.4s cubic-bezier(0.4,0,0.2,1) both;
  }
  @keyframes zen-flyin-right {
    from { transform: translateX(60px); }
    to   { transform: none; }
  }
  @keyframes zen-flyin-left {
    from { transform: translateX(-60px); }
    to   { transform: none; }
  }
  @keyframes zen-flyout-right {
    from { transform: none; }
    to   { transform: translateX(60px); }
  }
  @keyframes zen-flyout-left {
    from { transform: none; }
    to   { transform: translateX(-60px); }
  }
  `;
  document.head.appendChild(zenFlyAnimStyle);

  // Store previous grid positions for each pod
  if (!state._prevGridPositions) state._prevGridPositions = new Map();
})();
