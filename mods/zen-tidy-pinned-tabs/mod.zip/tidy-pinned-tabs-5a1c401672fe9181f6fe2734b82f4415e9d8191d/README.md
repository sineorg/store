<h1 align="center">Tidy Pinned Tabs</h1>

<div align="center">
  <a href="https://zen-browser.app/">
    <img width="180" alt="Zen Browser" src="https://github.com/user-attachments/assets/d6ab3ddf-6630-4062-92d0-22497d2a3f9a">
  </a>
</div>

<br>

<div align="center">
  <p>Pin. Shorten. Move on. Your model picks a title that fits the strip—<br>and you can always bring the long one back with a single modifier-click on the icon.</p>
</div>


## A calmer strip

<p align="left">Pinned tabs shouldn’t read like a paragraph. In Zen’s layout especially, a giant title fights for space and attention.<br><br>This mod asks an LLM for a tighter label the moment you pin.</p>


## See it in action

<table>
  <tr>
    <td width="50%">
      <h3>Pin, rename, keep browsing</h3>
      <img width="100%" height="100%" alt="Cap 2026-06-23 at 12 31 42" src="https://github.com/user-attachments/assets/ed448a73-2d48-41b4-bfbf-94c49b9587ab" alt="Pin, rename, keep browsing"/>
    </td>
    <td width="50%">
      <h3>Undo without drama</h3>
      <img width="100%" height="100%" alt="Cap 2026-06-23 at 12 26 58" src="https://github.com/user-attachments/assets/e973b039-1ab8-400e-afeb-41144f7b9b9a" alt="Pin, rename, keep browsing"/>
    </td>
  </tr>
</table>

**What you get**

- **Pin to rename** — With the mod on, a short title comes back from the provider you choose, with a bit of on-tab feedback so you know it landed.
- **Your stack** — Mistral, OpenAI, OpenRouter, Gemini, or **Ollama** at home. Keys live in preferences; Ollama stays on your machine.
- **Revert** — **Shift+click** the tab icon to restore the original (or switch to Alt or Meta in prefs). After a short window, the new title sticks.
- **Tunables** — Enable/disable, provider, model, Ollama URL, debug logging, and how you like to trigger revert.


## Get it

1. Install **Sine** if you don’t already have it  
   https://github.com/CosmoCreeper/Sine
2. Open **Settings → Sine Mods** (or **Cosine**)
3. Search for Tidy Pinned Tabs and install it. Or you can find it in the Store : <a href="https://sineorg.github.io/store/">Here</a>
