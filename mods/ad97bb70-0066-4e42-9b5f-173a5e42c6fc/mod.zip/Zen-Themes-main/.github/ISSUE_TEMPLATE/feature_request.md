---
name: Feature request
about: Suggest an idea for one of the Mods/Themes
title: "[Feature Request]"
labels: enhancement
assignees: ''

---

**The related Mod/Theme:**

**Your Enhancement Suggestion/Feature Request**
