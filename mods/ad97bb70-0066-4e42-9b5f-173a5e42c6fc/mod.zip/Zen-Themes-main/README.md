# Zen Themes

SuperPins is available through [Sine](https://github.com/CosmoCreeper/Sine) if you want to stay up-to-date, regardless of unmerged theme store pull requests.

A personal collection of my CSS Themes 🎨 for the [Zen Browser](https://zen-browser.app/).

## Currently there is 1 Mod available to be installed through [Zen's website](https://zen-browser.app/mods):

- [**SuperPins**](https://zen-browser.app/mods/ad97bb70-0066-4e42-9b5f-173a5e42c6fc)

![image](https://raw.githubusercontent.com/CosmoCreeper/Zen-Themes/refs/heads/main/SuperPins/image.png)

- **SuperGradient** (Officially working with Sine and revived since March 16th, 2026)

![image](https://raw.githubusercontent.com/CosmoCreeper/Zen-Themes/refs/heads/main/SuperGradient/image.png)

- **Galaxy/Dream Legacy Gradient** (Officially working with Sine and revived since March 16th, 2026)

![image](https://raw.githubusercontent.com/CosmoCreeper/Zen-Themes/refs/heads/main/GalaxyDreamGradient/image.png)

- **Super Url Bar** (Broken and currently discontinued)

![image](https://raw.githubusercontent.com/CosmoCreeper/Zen-Themes/refs/heads/main/SuperUrlBar/image.png)

---

You can find the code of each theme inside this repository!

**_Thanks to the original creator, [@JLBlk](https://github.com/JLBlk), for letting me maintain his mods!_** ❤️❤️
