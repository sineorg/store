# GalaxyDream Gradient Legacy

![image](https://raw.githubusercontent.com/CosmoCreeper/Zen-Themes/refs/heads/main/GalaxyDreamGradient/image.png)

This **Zen Mod** adds the legacy gradient themes "Zen Galaxy" and "Zen Dream" that have once been available in earlier versions of Zen.
It's a simple gradient that uses your Zen accent color (*Settings -> Look and Feel -> Theme Color*) as part of the gradient.
Additionally it automatically adapts to light/dark mode, as well as giving you the option to adjust the lightness
