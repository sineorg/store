# Floating Statusbar
A floating statusbar for Zen

![img](https://raw.githubusercontent.com/qumeqa/floating-statusbar/refs/heads/main/cover.png)