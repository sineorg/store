<h1 align="center">BetterZenGradientPicker</h1>
<div align="center">
    <a href="https://zen-browser.app/">
        <img width="180" alt="zen-badge-dark" src="https://github.com/user-attachments/assets/d6ab3ddf-6630-4062-92d0-22497d2a3f9a" />
    </a>
</div>

###

<div align="center">
  <img src="https://github.com/user-attachments/assets/5d280afc-6c6b-4d38-bdef-09dc4627885b" width="800" />
</div>

###

<h2 align="left">Why Does This Exist?</h2>

###

<p align="left">Zen's current gradient picker is great, but it is limited and does not have many features natively.<br><br>I constantly get annoyed by lack of control i have over the graadients created, that is why i made this mod to give user mode control and try to provide an overall better experience to users<br>This is an experimental JS mod which i cant guarentee that it is 100% reliable but as always I have tried my best to make it feel as native as possible. If you experience unusual bugs then please let me know...</p>

###

<h2 align="left">Features :)</h2>

<h3 align="left">1. Up to 6 colors </h3>
    <video
      src="https://github.com/user-attachments/assets/ecce00f1-fea6-44fd-a4e3-7c5f390c24af"
      autoplay
      loop
      muted
      playsinline
      width="100%">
    </video>

<h3 align="left">2. Save your gradient configuration! </h3>
    <video
      src="https://github.com/user-attachments/assets/546541e8-9b33-4402-aba5-ebd8e6c16815"
      autoplay
      loop
      muted
      playsinline
      width="100%">
    </video>

<h3 align="left">3. Rotation Knob </h3>
    <video
      src="https://github.com/user-attachments/assets/5db259c6-281d-4259-87a8-d81d68c3a604"
      autoplay
      loop
      muted
      playsinline
      width="100%">
    </video>

<h3 align="left">4. (New) Lightness Slider! ~ Added in v1.3</h3>
    <video
      src="https://github.com/user-attachments/assets/9863c01e-6c02-413c-b000-4a954ae41d5c"
      autoplay
      loop
      muted
      playsinline
      width="100%">
    </video>

<h3 align="left">5. Palette Switcher </h3>
    <video
      src="https://github.com/user-attachments/assets/3924dc3c-7b32-41b8-9cca-1f0cde47faef"
      autoplay
      loop
      muted
      playsinline
      width="100%">
    </video>

<h3 align="left">6. (Optional) Dynamic Light & Dark mode depending on gradient! </h3>
    <video
      src="https://github.com/user-attachments/assets/0ed89385-6dda-4ca6-b172-1e3a1559c842"
      autoplay
      loop
      muted
      playsinline
      width="100%">
    </video>

<h3 align="left">7. New Color Harmonies </h3>
    <p align="left"> • Floating Mode! </p>
        <video
          src="https://github.com/user-attachments/assets/213a74e5-7c42-48c7-974b-2447c5d4b878"
          autoplay
          loop
          muted
          playsinline
          width="100%">
        </video>
    <p align="left"> • Linear (For 2 & 3 colors) </p>
        <video
          src="https://github.com/user-attachments/assets/7bd5a18d-01b8-4ae5-874a-e50af06a975f"
          autoplay
          loop
          muted
          playsinline
          width="100%">
        </video>
    <p align="left"> • Hybrid (Linear + Analogous) for 3+ colors </p>
        <video
          src="https://github.com/user-attachments/assets/31e1d8f2-1e4c-42d5-9e04-c935a5a553de"
          autoplay
          loop
          muted
          playsinline
          width="100%">
        </video>

<h2 align="left">Installation</h2>

1. Install [Sine](https://github.com/CosmoCreeper/Sine) if you dont already have it.
2. Go to settings > Sine Mods (or Cosine if you are using that), Here you will see the marketplace of Sine. Search for "BetterZenGradientPicker" and install this mod directly from there.
